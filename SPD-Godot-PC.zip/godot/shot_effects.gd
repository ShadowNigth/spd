extends Node3D

var glow := StandardMaterial3D.new()


func _ready() -> void:
	glow.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	glow.albedo_color = Color("ffd185")


func emit_shot(muzzle: Vector3, target: Vector3, normal: Vector3, flash: bool) -> void:
	var effect := Node3D.new()
	add_child(effect)
	if flash:
		var light := OmniLight3D.new()
		light.light_color = Color("ffb96c")
		light.light_energy = 1.15
		light.omni_range = 3.4
		effect.add_child(light)
		light.global_position = muzzle
		var core := SphereMesh.new()
		core.radius = 0.028
		core.height = 0.056
		core.radial_segments = 6
		core.rings = 3
		var flame := MeshInstance3D.new()
		flame.mesh = core
		flame.material_override = glow
		effect.add_child(flame)
		flame.global_position = muzzle
	var lines := ImmediateMesh.new()
	lines.surface_begin(Mesh.PRIMITIVE_LINES, glow)
	# Begin beyond the near weapon so tracers are not a permanent crosshair.
	lines.surface_add_vertex(muzzle.lerp(target, 0.06))
	lines.surface_add_vertex(target)
	if not normal.is_zero_approx():
		for i in range(6):
			var jitter := Vector3(randf_range(-1.0, 1.0), randf_range(-1.0, 1.0), randf_range(-1.0, 1.0))
			lines.surface_add_vertex(target + normal * 0.015)
			lines.surface_add_vertex(target + (normal + jitter * 0.7) * randf_range(0.07, 0.21))
	lines.surface_end()
	var streak := MeshInstance3D.new()
	streak.mesh = lines
	streak.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	effect.add_child(streak)
	var lifetime := create_tween()
	lifetime.tween_interval(0.045)
	lifetime.tween_callback(effect.queue_free)

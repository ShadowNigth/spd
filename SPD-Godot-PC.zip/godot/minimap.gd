extends Control

const Layout = preload("res://maps/arena_layout.gd")
const MAPS := {"2000": preload("res://maps/2000_radar.png"),
	"awp_lego_2": preload("res://maps/awp_lego_2_radar.png")}

var map_id := ""
var player: Node3D
var combat: Node3D


func _process(_delta: float) -> void:
	queue_redraw()


func point(p: Vector3) -> Vector2:
	var bounds: Array = Layout.BOUNDS[map_id]
	return Vector2((p.x - bounds[0]) / bounds[2], (p.z - bounds[1]) / bounds[2]) * size


func _draw() -> void:
	if not MAPS.has(map_id) or not is_instance_valid(player):
		return
	draw_texture_rect(MAPS[map_id], Rect2(Vector2.ZERO, size), false)
	var area := Rect2(Vector2.ZERO, size)
	for node in get_tree().get_nodes_in_group("ground_weapons"):
		var drop := node as Node3D
		if drop == null or not is_instance_valid(combat) or not combat.is_ancestor_of(drop):
			continue
		var position_on_map := point(drop.global_position)
		if area.has_point(position_on_map):
			draw_circle(position_on_map, 2.0, Color("f4bb66"))
	var center := point(player.global_position)
	if area.has_point(center):
		var forward := Vector2(-player.global_basis.z.x, -player.global_basis.z.z).normalized()
		var right := forward.orthogonal()
		draw_colored_polygon(PackedVector2Array([center + forward * 8.0,
			center - forward * 5.0 + right * 5.0, center - forward * 5.0 - right * 5.0]), Color("a6f2e3"))
	draw_rect(area, Color("7e98a6"), false, 2.0)

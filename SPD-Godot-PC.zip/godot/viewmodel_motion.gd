extends RefCounted
## Additive movement layered over the imported skeletal clips, never over aim.
const REST := Vector3(0.024, -0.073, -0.105)
var phase := 0.0
var stride := 0.0
var sprint_blend := 0.0
var landing := 0.0
var recoil := 0.0
var inspect := 0.0
var inspect_length := 0.0
var previous_ground := true
var sway := Vector2.ZERO


func reset() -> void:
	inspect = 0.0
	inspect_length = 0.0
	recoil = 0.0


func start_inspect(length: float) -> void:
	inspect = length
	inspect_length = length


func update(pivot: Node3D, player: CharacterBody3D, delta: float, scoped: bool) -> void:
	var velocity := player.get_real_velocity()
	var speed := Vector2(velocity.x, velocity.z).length()
	var ground := player.is_on_floor()
	if ground and not previous_ground:
		landing = 1.0
	previous_ground = ground
	stride = move_toward(stride, clampf(speed / 6.0, 0.0, 1.0) if ground else 0.0, delta * 5.5)
	sprint_blend = move_toward(sprint_blend, 1.0 if speed > 6.25 and ground else 0.0, delta * 4.8)
	phase = fmod(phase + speed * delta * 1.6, TAU)
	landing = move_toward(landing, 0.0, delta * 5.0)
	recoil = move_toward(recoil, 0.0, delta * 8.0)
	inspect = move_toward(inspect, 0.0, delta)
	sway = sway.move_toward(Vector2.ZERO, delta * 0.85)
	var show_motion := 0.0 if scoped else 1.0
	var inspection := sin(PI * inspect / inspect_length) if inspect > 0.0 and inspect_length > 0.0 else 0.0
	pivot.position = REST + Vector3(sin(phase) * 0.012 * stride + sway.x * 0.026,
		-cos(phase * 2.0) * 0.007 * stride - sprint_blend * 0.055 - landing * 0.023 + sway.y * 0.022,
		recoil * 0.032 + inspection * 0.012) * show_motion
	pivot.rotation = Vector3(-sprint_blend * 0.18 + landing * 0.10 + recoil * 0.065,
		sway.x * 0.07 - inspection * 0.055, sin(phase) * 0.035 * stride - sprint_blend * 0.20 + inspection * 0.075) * show_motion

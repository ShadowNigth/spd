extends Control

var combat: Node


func _process(_delta: float) -> void:
	var active := is_instance_valid(combat) and bool(combat.get("scoped"))
	if visible != active:
		visible = active
	if active:
		queue_redraw()


func _draw() -> void:
	var center := size * 0.5
	var radius := minf(size.x, size.y) * 0.45
	# A filled ring with its outer edge beyond all four screen corners.
	var outer := size.length()
	for i in range(64):
		var a := Vector2.from_angle(TAU * float(i) / 64.0)
		var b := Vector2.from_angle(TAU * float(i + 1) / 64.0)
		draw_colored_polygon(PackedVector2Array([center + a * radius, center + b * radius,
			center + b * outer, center + a * outer]), Color.BLACK)
	draw_line(center - Vector2(radius, 0.0), center + Vector2(radius, 0.0), Color.BLACK, 1.5, true)
	draw_line(center - Vector2(0.0, radius), center + Vector2(0.0, radius), Color.BLACK, 1.5, true)

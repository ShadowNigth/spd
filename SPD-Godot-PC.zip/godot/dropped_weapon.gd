extends RigidBody3D

var item: Dictionary
var dimensions := Vector3.ONE
var ready_at := 0


func _ready() -> void:
	mass = float(item["mass"])
	collision_layer = 8
	collision_mask = 1
	linear_damp = 0.5
	angular_damp = 1.4
	var material := PhysicsMaterial.new()
	material.friction = 0.7
	material.bounce = 0.18
	physics_material_override = material
	var model := MeshInstance3D.new()
	model.mesh = load("res://combat_assets/%s_world.obj" % item["id"])
	add_child(model)
	var box := BoxShape3D.new()
	box.size = dimensions
	var collision := CollisionShape3D.new()
	collision.shape = box
	add_child(collision)
	ready_at = Time.get_ticks_msec() + 450


func _physics_process(_delta: float) -> void:
	if global_position.y < -65.0:
		queue_free()

extends Node3D

const Bot = preload("res://bot.gd")
const Archi = preload("res://combat_assets/archi/audio.gd")
const Motion = preload("res://viewmodel_motion.gd")
const Catalogue = preload("res://combat_assets/catalogue.gd")
const Layout = preload("res://maps/arena_layout.gd")
const Drop = preload("res://dropped_weapon.gd")
const WEAPONS: Array = Catalogue.ITEMS

var map_id := ""
var cash := 8000
var inventory: Array[Dictionary] = [{}, {}, {}]
var nearby: Drop
var interact_requested := false
var drop_requested := false
var notice := ""
var notice_left := 0.0
var player: CharacterBody3D
var camera: Camera3D
var spawns: Array
var hud := Label.new()
var weapon := Node3D.new()
var view: Node3D
var animator: AnimationPlayer
var view_busy := 0.0
var motion := Motion.new()
var cue := AudioStreamPlayer.new()
var inspect_duration := 0.0
var inspect_elapsed := 0.0
var inspect_event := 0
var audio := AudioStreamPlayer.new()
var slot := 0
var scoped := false
var suppressor_mesh: MeshInstance3D
var suppressor_left := 0.0
var suppressor_destination := false
var fx := preload("res://shot_effects.gd").new()
var wait := 0.0
var reload_left := 0.0
var reload_length := 0.0
var reload_event := 0
var reload_phase := ""
var health := 100
var remaining := 0
var trigger := false
var ended := false


func _ready() -> void:
	camera = player.get_node("Camera3D")
	camera.add_child(weapon)
	# Source clips are camera-relative; keep sleeves low and the muzzle toward -Z.
	weapon.position = Motion.REST
	add_child(audio)
	add_child(cue)
	cue.volume_db = -5.0
	add_child(fx)
	inventory[2] = fresh_item(weapon_by_id("knife"))
	inventory[1] = fresh_item(weapon_by_id("deagle" if map_id == "awp_lego_2" else "pist_glock18"))
	if map_id == "awp_lego_2":
		inventory[0] = fresh_item(weapon_by_id("awp"))
	switch_slot(0 if not inventory[0].is_empty() else 1)
	setup_arena.call_deferred()


func _exit_tree() -> void:
	if is_instance_valid(hud):
		hud.queue_free()


func setup_arena() -> void:
	await get_tree().physics_frame
	await get_tree().physics_frame
	if not is_inside_tree():
		return
	var candidates: Array[Vector3] = []
	for spawn: Dictionary in spawns:
		if spawn["team"] != "T":
			continue
		var p: Array = spawn["position"]
		var site := Vector3(p[0], p[1], p[2])
		if candidates.all(func(other: Vector3) -> bool: return other.distance_to(site) > 2.5):
			candidates.append(site)
	for i in range(mini(candidates.size(), 4)):
		var bot := Bot.new()
		bot.position = candidates[i] + Vector3.UP * 0.3
		bot.target = player
		bot.damage_player.connect(hurt_player)
		bot.defeated.connect(on_defeated)
		bot.variant = i % 2
		add_child(bot)
		remaining += 1

	if map_id == "2000":
		for marker: Dictionary in Layout.PICKUPS:
			var coords: Array = marker["position"]
			var at := Vector3(coords[0], coords[1], coords[2])
			var item := fresh_item(weapon_by_id(marker["id"]))
			var floor_ray := PhysicsRayQueryParameters3D.create(at + Vector3.UP, at - Vector3.UP * 1.8, 1)
			var floor_hit := get_world_3d().direct_space_state.intersect_ray(floor_ray)
			if not floor_hit.is_empty():
				var ground: Vector3 = floor_hit["position"]
				at.y = maxf(at.y, ground.y + float(item["size"][1]) * 0.5 + 0.04)
			spawn_drop(item, at, false)


func weapon_by_id(id: String) -> Dictionary:
	for entry: Dictionary in WEAPONS:
		if entry["id"] == id:
			return entry
	return {}


func fresh_item(data: Dictionary) -> Dictionary:
	var item := data.duplicate()
	item["loaded"] = int(data["capacity"])
	item["ammo"] = int(data["reserve"])
	item["suppressed"] = false
	return item


func slot_for(item: Dictionary) -> int:
	return 1 if item["kind"] == "pist" else 0


func allowed(item: Dictionary) -> bool:
	return map_id != "awp_lego_2" or str(item["id"]) in ["awp", "deagle", "knife"]


func can_shop() -> bool:
	if map_id != "2000" or ended:
		return false
	var lo: Array = Layout.BUY_ZONE[0]
	var hi: Array = Layout.BUY_ZONE[1]
	var feet := player.position + Vector3.UP * 0.25
	if feet.x >= lo[0] and feet.y >= lo[1] and feet.z >= lo[2] and feet.x <= hi[0] and feet.y <= hi[1] and feet.z <= hi[2]:
		return true
	for spawn: Dictionary in spawns:
		if spawn["team"] != "CT":
			continue
		var p: Array = spawn["position"]
		if player.position.distance_to(Vector3(p[0], p[1], p[2])) < 5.0:
			return true
	return false


func buy(data: Dictionary) -> bool:
	if not can_shop() or not allowed(data) or data["kind"] == "knife" or cash < int(data["price"]):
		return false
	cash -= int(data["price"])
	put_in_slot(fresh_item(data))
	return true


func put_in_slot(item: Dictionary) -> void:
	var target := slot_for(item)
	if not inventory[target].is_empty():
		throw_item(inventory[target])
	inventory[target] = item
	switch_slot(target)


func throw_item(item: Dictionary) -> void:
	var forward := -camera.global_basis.z
	# Keep the initial rigid body on the player's side of nearby walls.
	var at := player.global_position + Vector3.UP * 1.12
	spawn_drop(item, at, true, forward)


func spawn_drop(item: Dictionary, at: Vector3, thrown: bool, forward: Vector3 = Vector3.FORWARD) -> void:
	var drop := Drop.new()
	drop.item = item
	var size: Array = item["size"]
	drop.dimensions = Vector3(maxf(size[0], 0.035), maxf(size[1], 0.035), maxf(size[2], 0.035))
	drop.position = at
	add_child(drop)
	drop.add_to_group("ground_weapons")
	if thrown:
		drop.apply_central_impulse(forward * 3.1 + Vector3.UP * 1.2)
		drop.apply_torque_impulse(Vector3(0.09, 0.17, -0.13))


func find_pickup() -> Drop:
	var best: Drop = null
	var best_score := 3.0
	for node in get_tree().get_nodes_in_group("ground_weapons"):
		var drop := node as Drop
		if drop == null or not is_ancestor_of(drop) or drop.is_queued_for_deletion() or Time.get_ticks_msec() < drop.ready_at or not allowed(drop.item):
			continue
		var offset := drop.global_position - player.global_position
		if absf(offset.y) > 1.35 or offset.length() > 2.0:
			continue
		var direction := Vector3(offset.x, 0.0, offset.z).normalized()
		var dot := -player.global_basis.z.dot(direction)
		var score := offset.length() - dot * 0.5
		if dot < -0.15 or score >= best_score:
			continue
		var check := PhysicsRayQueryParameters3D.create(camera.global_position, drop.global_position, 1, [player.get_rid()])
		if not get_world_3d().direct_space_state.intersect_ray(check).is_empty():
			continue
		best_score = score
		best = drop
	return best


func switch_slot(index: int) -> void:
	if inventory[index].is_empty():
		return
	if is_instance_valid(view):
		weapon.remove_child(view)
		view.queue_free()
	scoped = false
	weapon.show()
	slot = index
	suppressor_left = 0.0
	suppressor_mesh = null
	reload_left = 0.0
	reload_phase = ""
	var scene := load("res://combat_assets/%s_view.glb" % inventory[slot]["id"]) as PackedScene
	view = scene.instantiate() as Node3D
	weapon.add_child(view)
	suppressor_mesh = view.find_child("Suppressor", true, false) as MeshInstance3D
	if suppressor_mesh != null:
		suppressor_mesh.visible = is_suppressed()
	for surface in view.find_children("*", "MeshInstance3D", true, false):
		var mesh := surface as MeshInstance3D
		mesh.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		mesh.extra_cull_margin = 0.8
	var animations := view.find_children("*", "AnimationPlayer", true, false)
	animator = animations[0] as AnimationPlayer if not animations.is_empty() else null
	motion.reset()
	inspect_duration = 0.0
	cue.stop()
	view_busy = play_clip(&"draw")
	play_cue(str(archi_audio().get("draw", "")))


func play_clip(clip: StringName) -> float:
	if animator == null or not animator.has_animation(clip):
		return 0.0
	var animation := animator.get_animation(clip)
	animation.loop_mode = Animation.LOOP_LINEAR if clip == &"idle" else Animation.LOOP_NONE
	if animator.current_animation == clip and clip != &"idle":
		animator.seek(0.0, true)
	else:
		animator.play(clip, 0.06)
	return animation.length


func _unhandled_input(event: InputEvent) -> void:
	if ended or Input.mouse_mode != Input.MOUSE_MODE_CAPTURED:
		return
	if event is InputEventMouseMotion:
		motion.sway = (motion.sway + event.relative * 0.003).limit_length(0.55)
	if suppressor_left > 0.0:
		return
	for index in range(inventory.size()):
		if event.is_action_pressed("weapon_%d" % (index + 1)):
			if index != slot:
				switch_slot(index)
			return
	if event.is_action_pressed("interact"):
		interact_requested = true
	elif event.is_action_pressed("drop"):
		drop_requested = true
	elif event.is_action_pressed("aim") and reload_left <= 0.0:
		if inventory[slot]["kind"] == "snip":
			scoped = not scoped
		elif suppressor_mesh != null and view_busy <= 0.0:
			toggle_suppressor()
	elif event.is_action_pressed("reload"):
		start_reload()
	elif event.is_action_pressed("inspect") and reload_left <= 0.0 and view_busy <= 0.0:
		view_busy = play_clip(&"lookat")
		inspect_duration = view_busy
		inspect_elapsed = 0.0
		inspect_event = 0
		motion.start_inspect(view_busy)
	elif event.is_action_pressed("fire"):
		trigger = true


func is_suppressed() -> bool:
	return bool(inventory[slot].get("suppressed", false))


func toggle_suppressor() -> void:
	suppressor_destination = not is_suppressed()
	var clip := &"attach" if suppressor_destination else &"deattach"
	var length := play_clip(clip)
	if length <= 0.0:
		return
	suppressor_left = length
	view_busy = length
	suppressor_mesh.show()
	var sounds: Dictionary = archi_audio().get("suppressor", {})
	play_cue(str(sounds.get(str(clip), "")))


func update_suppressor(delta: float) -> void:
	if suppressor_left <= 0.0:
		return
	suppressor_left = maxf(0.0, suppressor_left - delta)
	if suppressor_left == 0.0:
		inventory[slot]["suppressed"] = suppressor_destination
		if suppressor_mesh != null:
			suppressor_mesh.visible = suppressor_destination


func start_reload() -> void:
	if slot == 2 or reload_left > 0.0 or inventory[slot]["loaded"] == inventory[slot]["capacity"] or int(inventory[slot]["ammo"]) == 0:
		return
	scoped = false
	inspect_duration = 0.0
	motion.inspect = 0.0
	if animator != null and animator.has_animation(&"start_reload"):
		step_reload("start_reload")
	else:
		step_reload("reload")


func step_reload(phase: String) -> void:
	reload_phase = phase
	var clip := &"reload" if phase == "shell" else StringName(phase)
	var length := play_clip(clip)
	reload_left = length if length > 0.0 else 1.65
	view_busy = reload_left
	reload_length = reload_left
	reload_event = 0


func finish_reload() -> void:
	var item: Dictionary = inventory[slot]
	if reload_phase == "start_reload":
		step_reload("shell")
		return
	if reload_phase == "shell":
		item["loaded"] += 1
		item["ammo"] -= 1
		step_reload("shell" if int(item["loaded"]) < int(item["capacity"]) and int(item["ammo"]) > 0 else "after_reload")
	elif reload_phase == "reload":
		var rounds := mini(int(item["capacity"]) - int(item["loaded"]), int(item["ammo"]))
		item["loaded"] += rounds
		item["ammo"] -= rounds
		reload_phase = ""
	else:
		reload_phase = ""


func _physics_process(delta: float) -> void:
	if Input.mouse_mode != Input.MOUSE_MODE_CAPTURED or ended:
		trigger = false
		interact_requested = false
		drop_requested = false
		if animator != null:
			animator.speed_scale = 0.0
		update_hud()
		return
	if animator != null:
		animator.speed_scale = 1.0
	notice_left = maxf(notice_left - delta, 0.0)
	nearby = find_pickup()
	if drop_requested and slot != 2:
		throw_item(inventory[slot])
		inventory[slot] = {}
		switch_slot(2)
	if interact_requested and is_instance_valid(nearby):
		put_in_slot(nearby.item)
		nearby.queue_free()
		nearby = null
	interact_requested = false
	drop_requested = false
	update_suppressor(delta)
	wait = maxf(wait - delta, 0.0)
	view_busy = maxf(view_busy - delta, 0.0)
	if reload_left > 0.0:
		reload_left = maxf(0.0, reload_left - delta)
		var events: Array = inventory[slot]["events"] if reload_phase in ["reload", "shell"] else []
		while reload_event < events.size() and reload_length - reload_left >= float(events[reload_event][0]):
			var original: String = events[reload_event][1]
			var replacements: Dictionary = archi_audio().get("reload", {})
			play_cue(str(replacements.get(original, original)))
			reload_event += 1
		if reload_left == 0.0:
			finish_reload()
	var wants_fire := trigger or (bool(inventory[slot]["auto"]) and Input.is_action_pressed("fire"))
	if wants_fire and wait <= 0.0 and reload_left <= 0.0 and suppressor_left <= 0.0:
		view_busy = 0.0
		if slot == 2 or int(inventory[slot]["loaded"]) > 0:
			fire()
		else:
			start_reload()
	trigger = false
	if view_busy <= 0.0 and animator != null and animator.current_animation != &"idle":
		play_clip(&"idle")
	camera.fov = move_toward(camera.fov, 22.0 if scoped else 75.0, delta * 340.0)
	weapon.visible = not scoped
	update_inspect_audio(delta)
	motion.update(weapon, player, delta, scoped)
	update_hud()


func fire() -> void:
	var item: Dictionary = inventory[slot]
	var melee := slot == 2
	if not melee:
		item["loaded"] -= 1
	wait = float(item["delay"])
	var clip := &"stab1" if melee else &"shoot1"
	if item["id"] == "pist_elite":
		clip = &"shoot_left1" if int(item["loaded"]) % 2 == 0 else &"shoot_right1"
	view_busy = play_clip(clip)
	inspect_duration = 0.0
	motion.inspect = 0.0
	motion.recoil = 0.32 if melee else (1.0 if item["kind"] == "snip" else 0.6)
	var shots: Array = archi_audio().get("shots", [])
	var sound := "%s.ogg" % item["id"] if shots.is_empty() else str(shots.pick_random())
	if is_suppressed():
		sound = "%s_suppressed.ogg" % item["id"]
	elif shots.is_empty() and item["id"] == "pist_223":
		sound = "pist_223_unsuppressed.ogg"
	audio.stream = load("res://combat_assets/%s" % sound) as AudioStream
	audio.pitch_scale = randf_range(0.97, 1.03)
	audio.play()
	var from := camera.global_position
	var pellets := 7 if item["kind"] == "shot" else 1
	for i in range(pellets):
		var direction := -camera.global_basis.z
		if i > 0:
			direction = (direction + camera.global_basis.x * randf_range(-0.055, 0.055) + camera.global_basis.y * randf_range(-0.055, 0.055)).normalized()
		var end := from + direction * (1.9 if melee else 150.0)
		var query := PhysicsRayQueryParameters3D.create(from, end, 7, [player.get_rid()])
		var hit := get_world_3d().direct_space_state.intersect_ray(query)
		if i == 0 and not melee:
			var finish: Vector3 = hit.get("position", end)
			var normal: Vector3 = hit.get("normal", Vector3.ZERO)
			var muzzle := from + direction * 0.4 if scoped else camera.to_global(Vector3(0.066, -0.12, -0.53))
			fx.emit_shot(muzzle, finish, normal, not scoped and not is_suppressed() and item["id"] != "mp5sd")
		if not hit.is_empty() and hit.collider.has_method("take_damage"):
			hit.collider.take_damage(int(item["damage"]))


func archi_audio() -> Dictionary:
	return Archi.WEAPONS.get(inventory[slot].get("id", ""), {})


func play_cue(path: String) -> void:
	if path.is_empty():
		return
	cue.stream = load("res://combat_assets/%s" % path) as AudioStream
	cue.play()


func update_inspect_audio(delta: float) -> void:
	if inspect_duration <= 0.0:
		return
	inspect_elapsed += delta
	var events: Array = archi_audio().get("inspect", [])
	if not events.is_empty():
		# The Source clip is not loaded. Fit numbered frame cues to the local clip.
		var end_frame := maxf(240.0, float(events.back()[0]) + 12.0)
		while inspect_event < events.size() and inspect_elapsed >= float(events[inspect_event][0]) / end_frame * inspect_duration:
			play_cue(str(events[inspect_event][1]))
			inspect_event += 1
	if inspect_elapsed >= inspect_duration:
		inspect_duration = 0.0


func hurt_player(amount: int) -> void:
	if ended or Input.mouse_mode != Input.MOUSE_MODE_CAPTURED:
		return
	health = maxi(health - amount, 0)
	if health == 0:
		ended = true


func on_defeated() -> void:
	remaining -= 1
	cash += 300
	if remaining == 0:
		ended = true


func update_hud() -> void:
	var item: Dictionary = inventory[slot]
	var message := "R recargar   I inspeccionar   G soltar   E recoger"
	if map_id == "2000" and can_shop():
		message += "   B comprar"
	if suppressor_mesh != null:
		message += "   RMB silenciador"
	if suppressor_left > 0.0:
		message = "Colocando silenciador…" if suppressor_destination else "Quitando silenciador…"
	if reload_left > 0.0:
		message = "Recargando…"
	if is_instance_valid(nearby):
		message = "E recoger: " + str(nearby.item["name"])
	if notice_left > 0.0:
		message = notice
	if ended:
		message = ("Derrota" if health == 0 else "Victoria") + " — Esc: reiniciar o volver"
	var slots: PackedStringArray = []
	for index in range(inventory.size()):
		var label := str(inventory[index].get("name", "—"))
		slots.append("%s%d %s" % ["› " if index == slot else "", index + 1, label])
	var ammo := "—" if slot == 2 else "%d / %d" % [item["loaded"], item["ammo"]]
	hud.text = "%s   %s    |    Salud %d    |    $%d    |    Rivales %d\n%s\n%s" % [
		item["name"], ammo, health, cash, remaining, "     ".join(slots), message]

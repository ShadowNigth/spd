extends Node3D

const Bot = preload("res://bot.gd")
const ReloadAudio = preload("res://combat_assets/reload_events.gd")
const WEAPONS := [
	{"name": "AK-47", "view": preload("res://combat_assets/ak47_view.glb"),
	 "sound": preload("res://combat_assets/ak47.ogg"), "capacity": 30,
	 "reserve": 90, "delay": 0.11, "reload": 1.65, "damage": 34},
	{"name": "Desert Eagle", "view": preload("res://combat_assets/deagle_view.glb"),
	 "sound": preload("res://combat_assets/deagle.ogg"), "capacity": 7,
	 "reserve": 35, "delay": 0.32, "reload": 1.25, "damage": 55},
]
var player: CharacterBody3D
var camera: Camera3D
var spawns: Array
var hud := Label.new()
var weapon := Node3D.new()
var view: Node3D
var animator: AnimationPlayer
var view_busy := 0.0
var audio := AudioStreamPlayer.new()
var slot := 0
var magazines := [30, 7]
var reserve := [90, 35]
var wait := 0.0
var reload_left := 0.0
var reload_length := 0.0
var reload_event := 0
var health := 100
var remaining := 0
var trigger := false
var ended := false


func _ready() -> void:
	camera = player.get_node("Camera3D")
	camera.add_child(weapon)
	# Source clips are camera-relative; keep sleeves low and the muzzle toward -Z.
	weapon.position = Vector3(0.024, -0.073, -0.105)
	add_child(audio)
	switch_slot(0)
	setup_arena.call_deferred()


func _exit_tree() -> void:
	if is_instance_valid(hud):
		hud.queue_free()


func setup_arena() -> void:
	await get_tree().physics_frame
	await get_tree().physics_frame
	if not is_inside_tree():
		return
	var candidates: Array[Vector3] = []
	for spawn: Dictionary in spawns:
		if spawn["team"] != "T":
			continue
		var p: Array = spawn["position"]
		var site := Vector3(p[0], p[1], p[2])
		if candidates.all(func(other: Vector3) -> bool: return other.distance_to(site) > 2.5):
			candidates.append(site)
	for i in range(mini(candidates.size(), 4)):
		var bot := Bot.new()
		bot.position = candidates[i] + Vector3.UP * 0.3
		bot.target = player
		bot.damage_player.connect(hurt_player)
		bot.defeated.connect(on_defeated)
		bot.variant = i % 2
		add_child(bot)
		remaining += 1


func switch_slot(index: int) -> void:
	if is_instance_valid(view):
		weapon.remove_child(view)
		view.queue_free()
	slot = index
	reload_left = 0.0
	var scene: PackedScene = WEAPONS[slot]["view"]
	view = scene.instantiate() as Node3D
	weapon.add_child(view)
	for surface in view.find_children("*", "MeshInstance3D", true, false):
		var mesh := surface as MeshInstance3D
		mesh.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		mesh.extra_cull_margin = 0.8
	var animations := view.find_children("*", "AnimationPlayer", true, false)
	animator = animations[0] as AnimationPlayer if not animations.is_empty() else null
	view_busy = play_clip(&"draw")


func play_clip(clip: StringName) -> float:
	if animator == null or not animator.has_animation(clip):
		return 0.0
	var animation := animator.get_animation(clip)
	animation.loop_mode = Animation.LOOP_LINEAR if clip == &"idle" else Animation.LOOP_NONE
	if animator.current_animation == clip and clip != &"idle":
		animator.seek(0.0, true)
	else:
		animator.play(clip, 0.06)
	return animation.length


func _unhandled_input(event: InputEvent) -> void:
	if ended or Input.mouse_mode != Input.MOUSE_MODE_CAPTURED:
		return
	if event.is_action_pressed("weapon_1"):
		switch_slot(0)
	elif event.is_action_pressed("weapon_2"):
		switch_slot(1)
	elif event.is_action_pressed("reload"):
		start_reload()
	elif event.is_action_pressed("inspect") and reload_left <= 0.0 and view_busy <= 0.0:
		view_busy = play_clip(&"lookat")
	elif event.is_action_pressed("fire"):
		trigger = true


func start_reload() -> void:
	if reload_left > 0.0 or magazines[slot] == WEAPONS[slot]["capacity"] or reserve[slot] == 0:
		return
	var length := play_clip(&"reload")
	reload_left = length if length > 0.0 else float(WEAPONS[slot]["reload"])
	view_busy = reload_left
	reload_length = reload_left
	reload_event = 0


func _physics_process(delta: float) -> void:
	if Input.mouse_mode != Input.MOUSE_MODE_CAPTURED or ended:
		trigger = false
		if animator != null:
			animator.speed_scale = 0.0
		update_hud()
		return
	if animator != null:
		animator.speed_scale = 1.0
	wait = maxf(wait - delta, 0.0)
	view_busy = maxf(view_busy - delta, 0.0)
	if reload_left > 0.0:
		reload_left = maxf(0.0, reload_left - delta)
		var events: Array = ReloadAudio.EVENTS[slot]
		while reload_event < events.size() and reload_length - reload_left >= float(events[reload_event][0]):
			audio.stream = events[reload_event][1]
			audio.play()
			reload_event += 1
		if reload_left == 0.0:
			var rounds := mini(WEAPONS[slot]["capacity"] - magazines[slot], reserve[slot])
			magazines[slot] += rounds
			reserve[slot] -= rounds
	var wants_fire := trigger or (slot == 0 and Input.is_action_pressed("fire"))
	if wants_fire and wait <= 0.0 and reload_left <= 0.0:
		view_busy = 0.0
		if magazines[slot] > 0:
			fire()
		else:
			start_reload()
	trigger = false
	if view_busy <= 0.0 and animator != null and animator.current_animation != &"idle":
		play_clip(&"idle")
	update_hud()


func fire() -> void:
	magazines[slot] -= 1
	wait = WEAPONS[slot]["delay"]
	view_busy = play_clip(&"shoot1")
	audio.stream = WEAPONS[slot]["sound"]
	audio.play()
	var from := camera.global_position
	var query := PhysicsRayQueryParameters3D.create(from, from - camera.global_basis.z * 150.0,
		7, [player.get_rid()])
	var hit := get_world_3d().direct_space_state.intersect_ray(query)
	if not hit.is_empty() and hit.collider.has_method("take_damage"):
		hit.collider.take_damage(WEAPONS[slot]["damage"])


func hurt_player(amount: int) -> void:
	if ended or Input.mouse_mode != Input.MOUSE_MODE_CAPTURED:
		return
	health = maxi(health - amount, 0)
	if health == 0:
		ended = true


func on_defeated() -> void:
	remaining -= 1
	if remaining == 0:
		ended = true


func update_hud() -> void:
	var message := "Recargando…" if reload_left > 0.0 else "1 / 2: arma   R: recargar   I: inspeccionar"
	if ended:
		message = ("Derrota" if health == 0 else "Victoria") + " — Esc: reiniciar o volver"
	hud.text = "%s   %d / %d   |   Salud %d   |   Rivales %d\n%s" % [
		WEAPONS[slot]["name"], magazines[slot], reserve[slot], health, remaining, message]

extends Node3D

const Bot = preload("res://bot.gd")
const Crate = preload("res://crate.gd")
const WEAPONS := [
	{"name": "AK-47", "mesh": preload("res://combat_assets/ak47.obj"),
	 "sound": preload("res://combat_assets/ak47.ogg"), "capacity": 30,
	 "reserve": 90, "delay": 0.11, "reload": 1.65, "damage": 34},
	{"name": "Desert Eagle", "mesh": preload("res://combat_assets/deagle.obj"),
	 "sound": preload("res://combat_assets/deagle.ogg"), "capacity": 7,
	 "reserve": 35, "delay": 0.32, "reload": 1.25, "damage": 55},
]
var player: CharacterBody3D
var camera: Camera3D
var spawns: Array
var hud := Label.new()
var weapon := MeshInstance3D.new()
var audio := AudioStreamPlayer.new()
var slot := 0
var magazines := [30, 7]
var reserve := [90, 35]
var wait := 0.0
var reload_left := 0.0
var recoil := 0.0
var health := 100
var remaining := 0
var trigger := false
var ended := false


func _ready() -> void:
	camera = player.get_node("Camera3D")
	camera.add_child(weapon)
	weapon.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	weapon.scale = Vector3.ONE * 0.67
	add_child(audio)
	switch_slot(0)
	setup_arena.call_deferred()


func _exit_tree() -> void:
	if is_instance_valid(hud):
		hud.queue_free()


func setup_arena() -> void:
	await get_tree().physics_frame
	await get_tree().physics_frame
	if not is_inside_tree():
		return
	var candidates: Array[Vector3] = []
	for spawn: Dictionary in spawns:
		if spawn["team"] != "T":
			continue
		var p: Array = spawn["position"]
		var site := Vector3(p[0], p[1], p[2])
		if candidates.all(func(other: Vector3) -> bool: return other.distance_to(site) > 2.5):
			candidates.append(site)
	for i in range(mini(candidates.size(), 4)):
		var bot := Bot.new()
		bot.position = candidates[i] + Vector3.UP * 0.3
		bot.target = player
		bot.damage_player.connect(hurt_player)
		bot.defeated.connect(on_defeated)
		bot.variant = i % 2
		add_child(bot)
		remaining += 1
	# Snap practice props to original map floors, not to spawned actors.
	var forward := -player.global_basis.z
	var right := player.global_basis.x
	for side: float in [-1.0, 1.0]:
		var position_hint: Vector3 = player.global_position + forward * 4.5 + right * side * 1.8
		var query := PhysicsRayQueryParameters3D.create(position_hint + Vector3.UP * 2.0,
			position_hint - Vector3.UP * 6.0, 1)
		var hit := get_world_3d().direct_space_state.intersect_ray(query)
		if not hit.is_empty():
			var crate := Crate.new()
			crate.position = hit.position + Vector3.UP
			add_child(crate)


func switch_slot(index: int) -> void:
	slot = index
	reload_left = 0.0
	weapon.mesh = WEAPONS[slot]["mesh"]


func _unhandled_input(event: InputEvent) -> void:
	if ended or Input.mouse_mode != Input.MOUSE_MODE_CAPTURED:
		return
	if event.is_action_pressed("weapon_1"):
		switch_slot(0)
	elif event.is_action_pressed("weapon_2"):
		switch_slot(1)
	elif event.is_action_pressed("reload"):
		start_reload()
	elif event.is_action_pressed("fire"):
		trigger = true


func start_reload() -> void:
	if reload_left > 0.0 or magazines[slot] == WEAPONS[slot]["capacity"] or reserve[slot] == 0:
		return
	reload_left = WEAPONS[slot]["reload"]
	audio.stream = preload("res://combat_assets/reload.ogg")
	audio.play()


func _physics_process(delta: float) -> void:
	if Input.mouse_mode != Input.MOUSE_MODE_CAPTURED or ended:
		trigger = false
		update_hud()
		return
	wait = maxf(wait - delta, 0.0)
	if reload_left > 0.0:
		reload_left = maxf(0.0, reload_left - delta)
		if reload_left == 0.0:
			var rounds := mini(WEAPONS[slot]["capacity"] - magazines[slot], reserve[slot])
			magazines[slot] += rounds
			reserve[slot] -= rounds
	if (trigger or (slot == 0 and Input.is_action_pressed("fire"))) and wait <= 0.0 and reload_left <= 0.0:
		if magazines[slot] > 0:
			fire()
		else:
			start_reload()
	trigger = false
	recoil = move_toward(recoil, 0.0, delta * 9.0)
	var dip := sin(PI * reload_left / float(WEAPONS[slot]["reload"]))
	weapon.position = Vector3(0.24, -0.24 - dip * 0.32, -0.66 + recoil * 0.09)
	weapon.rotation = Vector3(recoil * 0.16 - dip * 0.5, 0.0, dip * 0.65)
	update_hud()


func fire() -> void:
	magazines[slot] -= 1
	wait = WEAPONS[slot]["delay"]
	recoil = 1.0
	audio.stream = WEAPONS[slot]["sound"]
	audio.play()
	var from := camera.global_position
	var query := PhysicsRayQueryParameters3D.create(from, from - camera.global_basis.z * 150.0,
		7, [player.get_rid()])
	var hit := get_world_3d().direct_space_state.intersect_ray(query)
	if not hit.is_empty() and hit.collider.has_method("take_damage"):
		hit.collider.take_damage(WEAPONS[slot]["damage"])


func hurt_player(amount: int) -> void:
	if ended or Input.mouse_mode != Input.MOUSE_MODE_CAPTURED:
		return
	health = maxi(health - amount, 0)
	if health == 0:
		ended = true


func on_defeated() -> void:
	remaining -= 1
	if remaining == 0:
		ended = true


func update_hud() -> void:
	var message := "Recargando…" if reload_left > 0.0 else "1 / 2: arma   R: recargar   LMB: disparar"
	if ended:
		message = ("Derrota" if health == 0 else "Victoria") + " — Esc: reiniciar o volver"
	hud.text = "%s   %d / %d   |   Salud %d   |   Rivales %d\n%s" % [
		WEAPONS[slot]["name"], magazines[slot], reserve[slot], health, remaining, message]

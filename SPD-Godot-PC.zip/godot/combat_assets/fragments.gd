extends RefCounted

const FRAGMENTS := [
	preload("res://combat_assets/fragment_0.obj"),
	preload("res://combat_assets/fragment_1.obj"),
	preload("res://combat_assets/fragment_2.obj"),
	preload("res://combat_assets/fragment_3.obj"),
	preload("res://combat_assets/fragment_4.obj"),
	preload("res://combat_assets/fragment_5.obj"),
	preload("res://combat_assets/fragment_6.obj"),
	preload("res://combat_assets/fragment_7.obj"),
	preload("res://combat_assets/fragment_8.obj"),
	preload("res://combat_assets/fragment_9.obj"),
	preload("res://combat_assets/fragment_10.obj"),
]
const OFFSETS := [
	Vector3(0.4044051, -0.55576855, 0.5198286),
	Vector3(0.86623085, 0.7949941, -0.57984656),
	Vector3(-0.17696996, 0.6970148, -0.6715562),
	Vector3(-0.6507203, -0.5712502, -0.56017596),
	Vector3(-0.7239273, 0.42156416, 0.10279383),
	Vector3(0.16703568, 0.39848575, 0.24524969),
	Vector3(0.7734586, 0.001861708, -0.27642506),
	Vector3(-0.44893813, -0.59824276, 0.65343183),
	Vector3(-0.38529152, -0.1545613, -0.3246929),
	Vector3(0.5024058, -0.9261371, -0.7027464),
	Vector3(-0.39617717, 0.8619693, 0.2961177),
]

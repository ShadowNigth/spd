extends RefCounted

const EVENTS := [
	[
		[0.3, preload("res://combat_assets/ak47_reload_0.ogg")],
		[1.0, preload("res://combat_assets/ak47_reload_1.ogg")],
		[1.6666666, preload("res://combat_assets/ak47_reload_2.ogg")],
	],
	[
		[0.26666668, preload("res://combat_assets/deagle_reload_0.ogg")],
		[0.6333333, preload("res://combat_assets/deagle_reload_1.ogg")],
		[1.3666667, preload("res://combat_assets/deagle_reload_2.ogg")],
		[1.5666667, preload("res://combat_assets/deagle_reload_3.ogg")],
	],
]

extends RefCounted

const EVENTS := [
	[
		[0.3, preload("res://combat_assets/ak47_reload_0.ogg")],
		[1.0, preload("res://combat_assets/ak47_reload_1.ogg")],
		[1.6666666, preload("res://combat_assets/ak47_reload_2.ogg")],
	],
	[
		[0.26666668, preload("res://combat_assets/deagle_reload_0.ogg")],
		[0.6333333, preload("res://combat_assets/deagle_reload_1.ogg")],
		[1.3666667, preload("res://combat_assets/deagle_reload_2.ogg")],
		[1.5666667, preload("res://combat_assets/deagle_reload_3.ogg")],
	],
	[
		[0.36666667, preload("res://combat_assets/m4a1_reload_0.ogg")],
		[1.1666666, preload("res://combat_assets/m4a1_reload_1.ogg")],
		[1.9, preload("res://combat_assets/m4a1_reload_2.ogg")],
	],
	[
		[0.23333333, preload("res://combat_assets/awp_reload_0.ogg")],
		[1.3333334, preload("res://combat_assets/awp_reload_1.ogg")],
		[2.0, preload("res://combat_assets/awp_reload_2.ogg")],
		[2.5666666, preload("res://combat_assets/awp_reload_3.ogg")],
		[2.9666667, preload("res://combat_assets/awp_reload_4.ogg")],
	],
	[
		[0.16666667, preload("res://combat_assets/mp5sd_reload_0.ogg")],
		[0.9, preload("res://combat_assets/mp5sd_reload_1.ogg")],
		[2.3, preload("res://combat_assets/mp5sd_reload_2.ogg")],
		[2.8333333, preload("res://combat_assets/mp5sd_reload_3.ogg")],
	],
]

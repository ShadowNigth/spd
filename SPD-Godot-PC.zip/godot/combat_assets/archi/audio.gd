extends RefCounted

const WEAPONS = {
  "ak47": {
    "shots": [
      "archi/ak47-1.wav",
      "archi/ak47-2.wav"
    ],
    "draw": "archi/cs2_ak47_draw.wav",
    "reload": {
      "ak47_reload_0.ogg": "archi/cs2_ak47_clipout.wav",
      "ak47_reload_1.ogg": "archi/cs2_ak47_clipin.wav",
      "ak47_reload_2.ogg": "archi/cs2_ak47_boltpull.wav"
    },
    "inspect": []
  },
  "deagle": {
    "shots": [
      "archi/deagle-1.wav",
      "archi/deagle-2.wav"
    ],
    "draw": "archi/cs2_deagle_draw.wav",
    "reload": {
      "deagle_reload_0.ogg": "archi/cs2_deagle_clipout.wav",
      "deagle_reload_1.ogg": "archi/cs2_deagle_clipin.wav",
      "deagle_reload_2.ogg": "archi/cs2_deagle_slideback.wav",
      "deagle_reload_3.ogg": "archi/cs2_deagle_slideforward.wav"
    },
    "inspect": [
      [
        9,
        "archi/cs2_deagle_lookat_f009.wav"
      ],
      [
        36,
        "archi/cs2_deagle_lookat_f036.wav"
      ],
      [
        57,
        "archi/cs2_deagle_lookat_f057.wav"
      ],
      [
        81,
        "archi/cs2_deagle_lookat_f081.wav"
      ],
      [
        111,
        "archi/cs2_deagle_lookat_f111.wav"
      ],
      [
        133,
        "archi/cs2_deagle_lookat_f133.wav"
      ],
      [
        166,
        "archi/cs2_deagle_lookat_f166.wav"
      ],
      [
        193,
        "archi/cs2_deagle_lookat_f193.wav"
      ],
      [
        228,
        "archi/cs2_deagle_lookat_f228.wav"
      ]
    ]
  },
  "m4a1": {
    "shots": [
      "archi/m4a1_unsil-1.wav",
      "archi/m4a1_unsil-2.wav"
    ],
    "draw": "archi/cs2_m4a1s_draw.wav",
    "reload": {
      "m4a1_reload_0.ogg": "archi/cs2_m4a1s_clipout.wav",
      "m4a1_reload_1.ogg": "archi/cs2_m4a1s_clipin.wav",
      "m4a1_reload_2.ogg": "archi/cs2_m4a1s_cliphit.wav"
    },
    "inspect": []
  },
  "awp": {
    "shots": [
      "archi/awp1.wav"
    ],
    "draw": "archi/cs2_awp_draw.wav",
    "reload": {
      "awp_reload_0.ogg": "archi/cs2_awp_clipout.wav",
      "awp_reload_1.ogg": "archi/cs2_awp_clipin.wav",
      "awp_reload_2.ogg": "archi/cs2_awp_cliphit.wav",
      "awp_reload_3.ogg": "archi/cs2_awp_boltback.wav",
      "awp_reload_4.ogg": "archi/cs2_awp_boltforward.wav"
    },
    "inspect": []
  },
  "mp5sd": {
    "shots": [
      "archi/mp5-1.wav",
      "archi/mp5-2.wav"
    ],
    "draw": "archi/cs2_mp5sd_draw.wav",
    "reload": {
      "mp5sd_reload_0.ogg": "archi/cs2_mp5sd_slideback.wav",
      "mp5sd_reload_1.ogg": "archi/cs2_mp5sd_clipout.wav",
      "mp5sd_reload_2.ogg": "archi/cs2_mp5sd_clipin.wav",
      "mp5sd_reload_3.ogg": "archi/cs2_mp5sd_slideforward.wav"
    },
    "inspect": []
  },
  "rif_aug": {
    "shots": [
      "archi/aug-1.wav"
    ],
    "draw": "archi/cs2_aug_draw.wav",
    "reload": {
      "rif_aug_reload_0.ogg": "archi/cs2_aug_clipout.wav",
      "rif_aug_reload_1.ogg": "archi/cs2_aug_clipin.wav",
      "rif_aug_reload_2.ogg": "archi/cs2_aug_cliphit.wav",
      "rif_aug_reload_3.ogg": "archi/cs2_aug_boltpull.wav",
      "rif_aug_reload_4.ogg": "archi/cs2_aug_boltrelease.wav"
    },
    "inspect": []
  },
  "rif_famas": {
    "shots": [
      "archi/famas-1.wav",
      "archi/famas-2.wav"
    ],
    "draw": "archi/cs2_famas_draw.wav",
    "reload": {
      "rif_famas_reload_0.ogg": "archi/cs2_famas_clipout.wav",
      "rif_famas_reload_1.ogg": "archi/cs2_famas_clipin.wav",
      "rif_famas_reload_2.ogg": "archi/cs2_famas_cliphit.wav",
      "rif_famas_reload_3.ogg": "archi/cs2_famas_boltback.wav",
      "rif_famas_reload_4.ogg": "archi/cs2_famas_boltforward.wav"
    },
    "inspect": []
  },
  "rif_galilar": {
    "shots": [
      "archi/galil-1.wav",
      "archi/galil-2.wav"
    ],
    "draw": "archi/cs2_galilar_draw.wav",
    "reload": {
      "rif_galilar_reload_0.ogg": "archi/cs2_galilar_clipout.wav",
      "rif_galilar_reload_1.ogg": "archi/cs2_galilar_clipin.wav",
      "rif_galilar_reload_2.ogg": "archi/cs2_galilar_boltback.wav",
      "rif_galilar_reload_3.ogg": "archi/cs2_galilar_boltforward.wav"
    },
    "inspect": []
  },
  "rif_m4a4": {
    "shots": [
      "archi/m4a1-1.wav"
    ],
    "draw": "archi/cs2_m4a1s_draw.wav",
    "reload": {
      "rif_m4a4_reload_0.ogg": "archi/cs2_m4a1s_clipout.wav",
      "rif_m4a4_reload_1.ogg": "archi/cs2_m4a1s_clipin.wav",
      "rif_m4a4_reload_2.ogg": "archi/cs2_m4a1s_cliphit.wav"
    },
    "inspect": []
  },
  "rif_sg556": {
    "shots": [],
    "draw": "archi/cs2_sg553_draw.wav",
    "reload": {
      "rif_sg556_reload_0.ogg": "archi/cs2_sg553_clipout.wav",
      "rif_sg556_reload_1.ogg": "archi/cs2_sg553_clipin.wav",
      "rif_sg556_reload_2.ogg": "archi/cs2_sg553_boltback.wav",
      "rif_sg556_reload_3.ogg": "archi/cs2_sg553_boltforward.wav"
    },
    "inspect": []
  },
  "pist_223": {
    "shots": [
      "archi/usp1.wav",
      "archi/usp2.wav"
    ],
    "draw": "archi/cs2_usps_draw.wav",
    "reload": {
      "pist_223_reload_0.ogg": "archi/cs2_usps_clipout.wav",
      "pist_223_reload_1.ogg": "archi/cs2_usps_clipin.wav",
      "pist_223_reload_2.ogg": "archi/cs2_usps_slideback.wav",
      "pist_223_reload_3.ogg": "archi/cs2_usps_sliderelease.wav"
    },
    "inspect": []
  },
  "pist_elite": {
    "shots": [
      "archi/elite_fire.wav"
    ],
    "draw": "archi/cs2_elites_draw.wav",
    "reload": {
      "pist_elite_reload_0.ogg": "archi/cs2_elites_clipout.wav",
      "pist_elite_reload_1.ogg": "archi/cs2_elites_clipout.wav",
      "pist_elite_reload_2.ogg": "archi/cs2_elites_leftclipin.wav",
      "pist_elite_reload_3.ogg": "archi/cs2_elites_rightclipin.wav",
      "pist_elite_reload_4.ogg": "archi/cs2_elites_sliderelease.wav",
      "pist_elite_reload_5.ogg": "archi/cs2_elites_sliderelease.wav"
    },
    "inspect": []
  },
  "pist_fiveseven": {
    "shots": [
      "archi/fiveseven-1.wav"
    ],
    "draw": "archi/cs2_fiveseven_draw.wav",
    "reload": {
      "pist_fiveseven_reload_0.ogg": "archi/cs2_fiveseven_clipout.wav",
      "pist_fiveseven_reload_1.ogg": "archi/cs2_fiveseven_clipin.wav",
      "pist_fiveseven_reload_2.ogg": "archi/cs2_fiveseven_slideback.wav",
      "pist_fiveseven_reload_3.ogg": "archi/cs2_fiveseven_sliderelease.wav"
    },
    "inspect": []
  },
  "pist_glock18": {
    "shots": [
      "archi/glock18-1.wav",
      "archi/glock18-2.wav"
    ],
    "draw": "archi/cs2_glock18_draw.wav",
    "reload": {
      "pist_glock18_reload_0.ogg": "archi/cs2_glock18_clipout.wav",
      "pist_glock18_reload_1.ogg": "archi/cs2_glock18_clipin.wav",
      "pist_glock18_reload_2.ogg": "archi/cs2_glock18_slideback.wav",
      "pist_glock18_reload_3.ogg": "archi/cs2_glock18_sliderelease.wav"
    },
    "inspect": []
  },
  "pist_hkp2000": {
    "shots": [],
    "draw": "archi/cs2_p2000_draw.wav",
    "reload": {
      "pist_hkp2000_reload_0.ogg": "archi/cs2_p2000_clipout.wav",
      "pist_hkp2000_reload_1.ogg": "archi/cs2_p2000_clipin.wav",
      "pist_hkp2000_reload_2.ogg": "archi/cs2_p2000_slideback.wav",
      "pist_hkp2000_reload_3.ogg": "archi/cs2_p2000_sliderelease.wav"
    },
    "inspect": []
  },
  "pist_p250": {
    "shots": [],
    "draw": "archi/cs2_p250_draw.wav",
    "reload": {
      "pist_p250_reload_0.ogg": "archi/cs2_p250_clipout.wav",
      "pist_p250_reload_1.ogg": "archi/cs2_p250_clipin.wav",
      "pist_p250_reload_2.ogg": "archi/cs2_p250_slideback.wav",
      "pist_p250_reload_3.ogg": "archi/cs2_p250_sliderelease.wav"
    },
    "inspect": []
  },
  "snip_g3sg1": {
    "shots": [
      "archi/g3sg1-1.wav"
    ],
    "draw": "archi/cs2_g3sg1_draw.wav",
    "reload": {
      "snip_g3sg1_reload_0.ogg": "archi/cs2_g3sg1_clipout.wav",
      "snip_g3sg1_reload_1.ogg": "archi/cs2_g3sg1_clipin.wav",
      "snip_g3sg1_reload_2.ogg": "archi/cs2_g3sg1_slideback.wav",
      "snip_g3sg1_reload_3.ogg": "archi/cs2_g3sg1_slideforward.wav"
    },
    "inspect": []
  },
  "snip_scar20": {
    "shots": [],
    "draw": "archi/cs2_scar20_draw.wav",
    "reload": {
      "snip_scar20_reload_0.ogg": "archi/cs2_scar20_clipout.wav",
      "snip_scar20_reload_1.ogg": "archi/cs2_scar20_clipin.wav",
      "snip_scar20_reload_2.ogg": "archi/cs2_scar20_boltforward.wav"
    },
    "inspect": []
  },
  "snip_ssg08": {
    "shots": [],
    "draw": "archi/cs2_ssg08_draw.wav",
    "reload": {
      "snip_ssg08_reload_0.ogg": "archi/cs2_ssg08_clipout.wav",
      "snip_ssg08_reload_1.ogg": "archi/cs2_ssg08_clipin.wav",
      "snip_ssg08_reload_2.ogg": "archi/cs2_ssg08_cliphit.wav",
      "snip_ssg08_reload_3.ogg": "archi/cs2_ssg08_boltback.wav",
      "snip_ssg08_reload_4.ogg": "archi/cs2_ssg08_boltforward.wav"
    },
    "inspect": []
  },
  "smg_mac10": {
    "shots": [
      "archi/mac10-1.wav"
    ],
    "draw": "archi/cs2_mac10_draw.wav",
    "reload": {
      "smg_mac10_reload_0.ogg": "archi/cs2_mac10_clipout.wav",
      "smg_mac10_reload_1.ogg": "archi/cs2_mac10_clipin.wav",
      "smg_mac10_reload_2.ogg": "archi/cs2_mac10_boltback.wav",
      "smg_mac10_reload_3.ogg": "archi/cs2_mac10_boltforward.wav"
    },
    "inspect": []
  },
  "smg_mp7": {
    "shots": [],
    "draw": "archi/cs2_mp7_draw.wav",
    "reload": {
      "smg_mp7_reload_0.ogg": "archi/cs2_mp7_clipout.wav",
      "smg_mp7_reload_1.ogg": "archi/cs2_mp7_clipin.wav",
      "smg_mp7_reload_2.ogg": "archi/cs2_mp7_slideback.wav",
      "smg_mp7_reload_3.ogg": "archi/cs2_mp7_slideforward.wav"
    },
    "inspect": []
  },
  "smg_mp9": {
    "shots": [],
    "draw": "archi/cs2_mp9_draw.wav",
    "reload": {
      "smg_mp9_reload_0.ogg": "archi/cs2_mp9_clipout.wav",
      "smg_mp9_reload_1.ogg": "archi/cs2_mp9_clipin.wav",
      "smg_mp9_reload_2.ogg": "archi/cs2_mp9_boltback.wav",
      "smg_mp9_reload_3.ogg": "archi/cs2_mp9_boltforward.wav"
    },
    "inspect": []
  },
  "smg_p90": {
    "shots": [
      "archi/p90-1.wav"
    ],
    "draw": "archi/cs2_p90_draw.wav",
    "reload": {
      "smg_p90_reload_1.ogg": "archi/cs2_p90_clipout.wav",
      "smg_p90_reload_2.ogg": "archi/cs2_p90_clipin.wav",
      "smg_p90_reload_3.ogg": "archi/cs2_p90_cliphit.wav",
      "smg_p90_reload_4.ogg": "archi/cs2_p90_boltback.wav",
      "smg_p90_reload_5.ogg": "archi/cs2_p90_boltforward.wav"
    },
    "inspect": []
  },
  "smg_ump45": {
    "shots": [
      "archi/ump45-1.wav"
    ],
    "draw": "archi/cs2_ump45_draw.wav",
    "reload": {
      "smg_ump45_reload_0.ogg": "archi/cs2_ump45_clipout.wav",
      "smg_ump45_reload_1.ogg": "archi/cs2_ump45_clipin.wav",
      "smg_ump45_reload_2.ogg": "archi/cs2_ump45_boltback.wav",
      "smg_ump45_reload_3.ogg": "archi/cs2_ump45_boltforward.wav"
    },
    "inspect": []
  },
  "shot_nova": {
    "shots": [],
    "draw": "archi/cs2_nova_draw.wav",
    "reload": {},
    "inspect": []
  },
  "shot_sawedoff": {
    "shots": [],
    "draw": "archi/cs2_sawedoff_draw.wav",
    "reload": {},
    "inspect": []
  },
  "shot_xm1014": {
    "shots": [
      "archi/xm1014-1.wav"
    ],
    "draw": "archi/cs2_xm1014_draw.wav",
    "reload": {},
    "inspect": []
  },
  "mach_m249": {
    "shots": [
      "archi/m249-1.wav",
      "archi/m249-2.wav"
    ],
    "draw": "archi/cs2_m249_draw.wav",
    "reload": {
      "mach_m249_reload_0.ogg": "archi/cs2_m249_coverup.wav",
      "mach_m249_reload_1.ogg": "archi/cs2_m249_boxout.wav",
      "mach_m249_reload_2.ogg": "archi/cs2_m249_boxin.wav",
      "mach_m249_reload_3.ogg": "archi/cs2_m249_chain.wav",
      "mach_m249_reload_4.ogg": "archi/cs2_m249_coverdown.wav",
      "mach_m249_reload_5.ogg": "archi/cs2_m249_pump.wav"
    },
    "inspect": []
  },
  "mach_negev": {
    "shots": [],
    "draw": "archi/cs2_negev_draw.wav",
    "reload": {
      "mach_negev_reload_0.ogg": "archi/cs2_negev_coverup.wav",
      "mach_negev_reload_1.ogg": "archi/cs2_negev_boxout.wav",
      "mach_negev_reload_2.ogg": "archi/cs2_negev_boxin.wav",
      "mach_negev_reload_3.ogg": "archi/cs2_negev_chain.wav",
      "mach_negev_reload_4.ogg": "archi/cs2_negev_coverdown.wav",
      "mach_negev_reload_5.ogg": "archi/cs2_negev_pump.wav"
    },
    "inspect": []
  }
}

extends RefCounted

const ITEMS = [
  {
    "id": "ak47",
    "name": "AK-47",
    "kind": "rif",
    "capacity": 30,
    "damage": 34,
    "delay": 0.11,
    "price": 2700,
    "mass": 3.5,
    "reserve": 90,
    "events": [
      [
        0.3,
        "ak47_reload_0.ogg"
      ],
      [
        1.0,
        "ak47_reload_1.ogg"
      ],
      [
        1.6666666,
        "ak47_reload_2.ogg"
      ]
    ],
    "size": [
      1.0500985383987427,
      0.08273195661604404,
      0.30354638397693634
    ],
    "auto": true
  },
  {
    "id": "deagle",
    "name": "Desert Eagle",
    "kind": "pist",
    "capacity": 7,
    "damage": 55,
    "delay": 0.32,
    "price": 700,
    "mass": 1.9,
    "reserve": 21,
    "events": [
      [
        0.26666668,
        "deagle_reload_0.ogg"
      ],
      [
        0.6333333,
        "deagle_reload_1.ogg"
      ],
      [
        1.3666667,
        "deagle_reload_2.ogg"
      ],
      [
        1.5666667,
        "deagle_reload_3.ogg"
      ]
    ],
    "size": [
      0.3602590784430504,
      0.041811175644397736,
      0.19356273859739304
    ],
    "auto": false
  },
  {
    "id": "m4a1",
    "name": "M4A1",
    "kind": "rif",
    "capacity": 30,
    "damage": 30,
    "delay": 0.095,
    "price": 3100,
    "mass": 3.1,
    "reserve": 90,
    "events": [
      [
        0.36666667,
        "m4a1_reload_0.ogg"
      ],
      [
        1.1666666,
        "m4a1_reload_1.ogg"
      ],
      [
        1.9,
        "m4a1_reload_2.ogg"
      ]
    ],
    "size": [
      1.0106355845928192,
      0.09272405132651329,
      0.31148451566696167
    ],
    "auto": true
  },
  {
    "id": "awp",
    "name": "AWP",
    "kind": "snip",
    "capacity": 10,
    "damage": 100,
    "delay": 1.05,
    "price": 4750,
    "mass": 6.5,
    "reserve": 30,
    "events": [
      [
        0.23333333,
        "awp_reload_0.ogg"
      ],
      [
        1.3333334,
        "awp_reload_1.ogg"
      ],
      [
        2.0,
        "awp_reload_2.ogg"
      ],
      [
        2.5666666,
        "awp_reload_3.ogg"
      ],
      [
        2.9666667,
        "awp_reload_4.ogg"
      ]
    ],
    "size": [
      1.466039627790451,
      0.12031138315796852,
      0.27220651134848595
    ],
    "auto": false
  },
  {
    "id": "mp5sd",
    "name": "MP5-SD",
    "kind": "smg",
    "capacity": 30,
    "damage": 22,
    "delay": 0.075,
    "price": 1500,
    "mass": 3.1,
    "reserve": 90,
    "events": [
      [
        0.16666667,
        "mp5sd_reload_0.ogg"
      ],
      [
        0.9,
        "mp5sd_reload_1.ogg"
      ],
      [
        2.3,
        "mp5sd_reload_2.ogg"
      ],
      [
        2.8333333,
        "mp5sd_reload_3.ogg"
      ]
    ],
    "size": [
      0.6803371906280518,
      0.0623562503606081,
      0.2758813053369522
    ],
    "auto": true
  },
  {
    "id": "rif_aug",
    "name": "AUG",
    "kind": "rif",
    "capacity": 30,
    "damage": 30,
    "delay": 0.1,
    "price": 3300,
    "mass": 3.6,
    "reserve": 90,
    "events": [
      [
        0.5,
        "rif_aug_reload_0.ogg"
      ],
      [
        1.4666667,
        "rif_aug_reload_1.ogg"
      ],
      [
        2.0,
        "rif_aug_reload_2.ogg"
      ],
      [
        2.6333334,
        "rif_aug_reload_3.ogg"
      ],
      [
        2.8,
        "rif_aug_reload_4.ogg"
      ]
    ],
    "size": [
      0.8418465554714203,
      0.1029530018568039,
      0.3537403345108032
    ],
    "auto": true
  },
  {
    "id": "rif_famas",
    "name": "FAMAS",
    "kind": "rif",
    "capacity": 25,
    "damage": 27,
    "delay": 0.09,
    "price": 2050,
    "mass": 3.4,
    "reserve": 75,
    "events": [
      [
        0.5,
        "rif_famas_reload_0.ogg"
      ],
      [
        1.4,
        "rif_famas_reload_1.ogg"
      ],
      [
        1.9,
        "rif_famas_reload_2.ogg"
      ],
      [
        2.5333333,
        "rif_famas_reload_3.ogg"
      ],
      [
        2.6,
        "rif_famas_reload_4.ogg"
      ]
    ],
    "size": [
      0.895108163356781,
      0.07218790426850319,
      0.34134308993816376
    ],
    "auto": true
  },
  {
    "id": "rif_galilar",
    "name": "Galil AR",
    "kind": "rif",
    "capacity": 35,
    "damage": 28,
    "delay": 0.09,
    "price": 1800,
    "mass": 3.7,
    "reserve": 105,
    "events": [
      [
        0.43333334,
        "rif_galilar_reload_0.ogg"
      ],
      [
        1.0666667,
        "rif_galilar_reload_1.ogg"
      ],
      [
        1.8333334,
        "rif_galilar_reload_2.ogg"
      ],
      [
        2.0666666,
        "rif_galilar_reload_3.ogg"
      ]
    ],
    "size": [
      0.8928984701633453,
      0.08212658017873764,
      0.29387858510017395
    ],
    "auto": true
  },
  {
    "id": "rif_m4a4",
    "name": "M4A4",
    "kind": "rif",
    "capacity": 30,
    "damage": 31,
    "delay": 0.09,
    "price": 3100,
    "mass": 3.4,
    "reserve": 90,
    "events": [
      [
        0.36666667,
        "rif_m4a4_reload_0.ogg"
      ],
      [
        1.1666666,
        "rif_m4a4_reload_1.ogg"
      ],
      [
        1.9,
        "rif_m4a4_reload_2.ogg"
      ]
    ],
    "size": [
      0.8830654323101044,
      0.0749676264822483,
      0.282813124358654
    ],
    "auto": true
  },
  {
    "id": "rif_sg556",
    "name": "SG 553",
    "kind": "rif",
    "capacity": 30,
    "damage": 34,
    "delay": 0.1,
    "price": 3000,
    "mass": 3.7,
    "reserve": 90,
    "events": [
      [
        0.3,
        "rif_sg556_reload_0.ogg"
      ],
      [
        0.96666664,
        "rif_sg556_reload_1.ogg"
      ],
      [
        1.9333333,
        "rif_sg556_reload_2.ogg"
      ],
      [
        2.2,
        "rif_sg556_reload_3.ogg"
      ]
    ],
    "size": [
      0.9857718646526337,
      0.0889539010822773,
      0.34286289662122726
    ],
    "auto": true
  },
  {
    "id": "pist_223",
    "name": "USP",
    "kind": "pist",
    "capacity": 12,
    "damage": 30,
    "delay": 0.18,
    "price": 200,
    "mass": 0.9,
    "reserve": 36,
    "events": [
      [
        0.4,
        "pist_223_reload_0.ogg"
      ],
      [
        0.8333333,
        "pist_223_reload_1.ogg"
      ],
      [
        1.4666667,
        "pist_223_reload_2.ogg"
      ],
      [
        1.6666666,
        "pist_223_reload_3.ogg"
      ]
    ],
    "size": [
      0.23557567596435547,
      0.03529527597129345,
      0.16420849785208702
    ],
    "auto": false
  },
  {
    "id": "pist_elite",
    "name": "Dual Berettas",
    "kind": "pist",
    "capacity": 30,
    "damage": 24,
    "delay": 0.15,
    "price": 300,
    "mass": 1.9,
    "reserve": 90,
    "events": [
      [
        0.16666667,
        "pist_elite_reload_0.ogg"
      ],
      [
        0.23333333,
        "pist_elite_reload_1.ogg"
      ],
      [
        1.6333333,
        "pist_elite_reload_2.ogg"
      ],
      [
        2.8,
        "pist_elite_reload_3.ogg"
      ],
      [
        3.4,
        "pist_elite_reload_4.ogg"
      ],
      [
        3.5666666,
        "pist_elite_reload_5.ogg"
      ]
    ],
    "size": [
      0.3185476139187813,
      0.08449759893119335,
      0.22211302816867828
    ],
    "auto": false
  },
  {
    "id": "pist_fiveseven",
    "name": "Five-SeveN",
    "kind": "pist",
    "capacity": 20,
    "damage": 28,
    "delay": 0.15,
    "price": 500,
    "mass": 0.7,
    "reserve": 60,
    "events": [
      [
        0.4,
        "pist_fiveseven_reload_0.ogg"
      ],
      [
        0.8666667,
        "pist_fiveseven_reload_1.ogg"
      ],
      [
        1.4666667,
        "pist_fiveseven_reload_2.ogg"
      ],
      [
        1.6333333,
        "pist_fiveseven_reload_3.ogg"
      ]
    ],
    "size": [
      0.2516295462846756,
      0.04136187583208084,
      0.17541874572634697
    ],
    "auto": false
  },
  {
    "id": "pist_glock18",
    "name": "Glock-18",
    "kind": "pist",
    "capacity": 20,
    "damage": 24,
    "delay": 0.15,
    "price": 200,
    "mass": 0.7,
    "reserve": 60,
    "events": [
      [
        0.4,
        "pist_glock18_reload_0.ogg"
      ],
      [
        0.8333333,
        "pist_glock18_reload_1.ogg"
      ],
      [
        1.4666667,
        "pist_glock18_reload_2.ogg"
      ],
      [
        1.6666666,
        "pist_glock18_reload_3.ogg"
      ]
    ],
    "size": [
      0.2577047012746334,
      0.04130837507545948,
      0.16157730296254158
    ],
    "auto": false
  },
  {
    "id": "pist_hkp2000",
    "name": "P2000",
    "kind": "pist",
    "capacity": 13,
    "damage": 30,
    "delay": 0.17,
    "price": 200,
    "mass": 0.7,
    "reserve": 39,
    "events": [
      [
        0.4,
        "pist_hkp2000_reload_0.ogg"
      ],
      [
        0.8666667,
        "pist_hkp2000_reload_1.ogg"
      ],
      [
        1.4666667,
        "pist_hkp2000_reload_2.ogg"
      ],
      [
        1.6666666,
        "pist_hkp2000_reload_3.ogg"
      ]
    ],
    "size": [
      0.2314397096633911,
      0.0435106735676527,
      0.17560803145170212
    ],
    "auto": false
  },
  {
    "id": "pist_p250",
    "name": "P250",
    "kind": "pist",
    "capacity": 13,
    "damage": 32,
    "delay": 0.17,
    "price": 300,
    "mass": 0.8,
    "reserve": 39,
    "events": [
      [
        0.36666667,
        "pist_p250_reload_0.ogg"
      ],
      [
        0.8,
        "pist_p250_reload_1.ogg"
      ],
      [
        1.4666667,
        "pist_p250_reload_2.ogg"
      ],
      [
        1.6666666,
        "pist_p250_reload_3.ogg"
      ]
    ],
    "size": [
      0.2660457156598568,
      0.03942449949681759,
      0.18344420567154884
    ],
    "auto": false
  },
  {
    "id": "pist_tec9",
    "name": "Tec-9",
    "kind": "pist",
    "capacity": 18,
    "damage": 30,
    "delay": 0.14,
    "price": 500,
    "mass": 1.2,
    "reserve": 54,
    "events": [
      [
        0.4,
        "pist_tec9_reload_0.ogg"
      ],
      [
        1.2,
        "pist_tec9_reload_1.ogg"
      ],
      [
        1.8333334,
        "pist_tec9_reload_2.ogg"
      ],
      [
        2.0666666,
        "pist_tec9_reload_3.ogg"
      ]
    ],
    "size": [
      0.33049526810646057,
      0.05846724845468998,
      0.251027449965477
    ],
    "auto": false
  },
  {
    "id": "snip_g3sg1",
    "name": "G3SG1",
    "kind": "snip",
    "capacity": 20,
    "damage": 64,
    "delay": 0.28,
    "price": 5000,
    "mass": 5.5,
    "reserve": 60,
    "events": [
      [
        0.53333336,
        "snip_g3sg1_reload_0.ogg"
      ],
      [
        2.4333334,
        "snip_g3sg1_reload_1.ogg"
      ],
      [
        3.2333333,
        "snip_g3sg1_reload_2.ogg"
      ],
      [
        3.4666667,
        "snip_g3sg1_reload_3.ogg"
      ]
    ],
    "size": [
      1.1383424699306488,
      0.06455602496862411,
      0.29644620791077614
    ],
    "auto": false
  },
  {
    "id": "snip_scar20",
    "name": "SCAR-20",
    "kind": "snip",
    "capacity": 20,
    "damage": 65,
    "delay": 0.28,
    "price": 5000,
    "mass": 5.0,
    "reserve": 60,
    "events": [
      [
        0.43333334,
        "snip_scar20_reload_0.ogg"
      ],
      [
        1.2666667,
        "snip_scar20_reload_1.ogg"
      ],
      [
        1.9333333,
        "snip_scar20_reload_2.ogg"
      ]
    ],
    "size": [
      1.194877028465271,
      0.07330542430281639,
      0.3031521551311016
    ],
    "auto": false
  },
  {
    "id": "snip_ssg08",
    "name": "SSG 08",
    "kind": "snip",
    "capacity": 10,
    "damage": 75,
    "delay": 0.92,
    "price": 1700,
    "mass": 3.8,
    "reserve": 30,
    "events": [
      [
        0.3,
        "snip_ssg08_reload_0.ogg"
      ],
      [
        1.4666667,
        "snip_ssg08_reload_1.ogg"
      ],
      [
        1.9666667,
        "snip_ssg08_reload_2.ogg"
      ],
      [
        2.6,
        "snip_ssg08_reload_3.ogg"
      ],
      [
        3.0,
        "snip_ssg08_reload_4.ogg"
      ]
    ],
    "size": [
      1.3339998424053192,
      0.10271869599819183,
      0.32059210538864136
    ],
    "auto": false
  },
  {
    "id": "smg_bizon",
    "name": "PP-Bizon",
    "kind": "smg",
    "capacity": 64,
    "damage": 19,
    "delay": 0.08,
    "price": 1400,
    "mass": 2.7,
    "reserve": 192,
    "events": [
      [
        0.33333334,
        "smg_bizon_reload_0.ogg"
      ],
      [
        1.0333333,
        "smg_bizon_reload_1.ogg"
      ],
      [
        1.6,
        "smg_bizon_reload_2.ogg"
      ],
      [
        1.8666667,
        "smg_bizon_reload_3.ogg"
      ]
    ],
    "size": [
      0.6983471810817719,
      0.06449992768466473,
      0.19246447831392288
    ],
    "auto": true
  },
  {
    "id": "smg_mac10",
    "name": "MAC-10",
    "kind": "smg",
    "capacity": 30,
    "damage": 22,
    "delay": 0.075,
    "price": 1050,
    "mass": 2.8,
    "reserve": 90,
    "events": [
      [
        0.3,
        "smg_mac10_reload_0.ogg"
      ],
      [
        1.0,
        "smg_mac10_reload_1.ogg"
      ],
      [
        1.6666666,
        "smg_mac10_reload_2.ogg"
      ],
      [
        2.0,
        "smg_mac10_reload_3.ogg"
      ]
    ],
    "size": [
      0.3263094797730446,
      0.05314342491328716,
      0.27878357470035553
    ],
    "auto": true
  },
  {
    "id": "smg_mp7",
    "name": "MP7",
    "kind": "smg",
    "capacity": 30,
    "damage": 24,
    "delay": 0.08,
    "price": 1500,
    "mass": 1.9,
    "reserve": 90,
    "events": [
      [
        0.3,
        "smg_mp7_reload_0.ogg"
      ],
      [
        1.3666667,
        "smg_mp7_reload_1.ogg"
      ],
      [
        2.1,
        "smg_mp7_reload_2.ogg"
      ],
      [
        2.3333333,
        "smg_mp7_reload_3.ogg"
      ]
    ],
    "size": [
      0.4195586293935776,
      0.04582122527062893,
      0.30499348044395447
    ],
    "auto": true
  },
  {
    "id": "smg_mp9",
    "name": "MP9",
    "kind": "smg",
    "capacity": 30,
    "damage": 21,
    "delay": 0.07,
    "price": 1250,
    "mass": 1.4,
    "reserve": 90,
    "events": [
      [
        0.23333333,
        "smg_mp9_reload_0.ogg"
      ],
      [
        0.8,
        "smg_mp9_reload_1.ogg"
      ],
      [
        1.3333334,
        "smg_mp9_reload_2.ogg"
      ],
      [
        1.5333333,
        "smg_mp9_reload_3.ogg"
      ]
    ],
    "size": [
      0.6172986328601837,
      0.05654187500476837,
      0.2938523143529892
    ],
    "auto": true
  },
  {
    "id": "smg_p90",
    "name": "P90",
    "kind": "smg",
    "capacity": 50,
    "damage": 23,
    "delay": 0.075,
    "price": 2350,
    "mass": 2.6,
    "reserve": 150,
    "events": [
      [
        0.33333334,
        "smg_p90_reload_0.ogg"
      ],
      [
        0.4,
        "smg_p90_reload_1.ogg"
      ],
      [
        1.3666667,
        "smg_p90_reload_2.ogg"
      ],
      [
        1.9333333,
        "smg_p90_reload_3.ogg"
      ],
      [
        2.7333333,
        "smg_p90_reload_4.ogg"
      ],
      [
        2.9666667,
        "smg_p90_reload_5.ogg"
      ]
    ],
    "size": [
      0.510489895939827,
      0.05919242464005947,
      0.20724480599164963
    ],
    "auto": true
  },
  {
    "id": "smg_ump45",
    "name": "UMP-45",
    "kind": "smg",
    "capacity": 25,
    "damage": 28,
    "delay": 0.09,
    "price": 1200,
    "mass": 2.3,
    "reserve": 75,
    "events": [
      [
        0.26666668,
        "smg_ump45_reload_0.ogg"
      ],
      [
        1.3666667,
        "smg_ump45_reload_1.ogg"
      ],
      [
        2.1333334,
        "smg_ump45_reload_2.ogg"
      ],
      [
        2.4333334,
        "smg_ump45_reload_3.ogg"
      ]
    ],
    "size": [
      0.6270233392715454,
      0.05934950150549412,
      0.31381213665008545
    ],
    "auto": true
  },
  {
    "id": "shot_mag7",
    "name": "MAG-7",
    "kind": "shot",
    "capacity": 5,
    "damage": 16,
    "delay": 0.78,
    "price": 1300,
    "mass": 4.0,
    "reserve": 15,
    "events": [
      [
        0.23333333,
        "shot_mag7_reload_0.ogg"
      ],
      [
        0.8666667,
        "shot_mag7_reload_1.ogg"
      ],
      [
        1.8,
        "shot_mag7_reload_2.ogg"
      ],
      [
        2.0,
        "shot_mag7_reload_3.ogg"
      ]
    ],
    "size": [
      0.5534249395132065,
      0.056018026545643806,
      0.22359585016965866
    ],
    "auto": false
  },
  {
    "id": "shot_nova",
    "name": "Nova",
    "kind": "shot",
    "capacity": 8,
    "damage": 15,
    "delay": 0.82,
    "price": 1050,
    "mass": 3.3,
    "reserve": 24,
    "events": [],
    "size": [
      1.0612184405326843,
      0.053976474329829216,
      0.2197067067027092
    ],
    "auto": false
  },
  {
    "id": "shot_sawedoff",
    "name": "Sawed-Off",
    "kind": "shot",
    "capacity": 7,
    "damage": 17,
    "delay": 0.85,
    "price": 1100,
    "mass": 2.9,
    "reserve": 21,
    "events": [],
    "size": [
      0.6814480796456337,
      0.046803224831819534,
      0.1396690234541893
    ],
    "auto": false
  },
  {
    "id": "shot_xm1014",
    "name": "XM1014",
    "kind": "shot",
    "capacity": 7,
    "damage": 13,
    "delay": 0.33,
    "price": 2000,
    "mass": 3.8,
    "reserve": 21,
    "events": [],
    "size": [
      1.008483648300171,
      0.0737637747079134,
      0.19580193236470222
    ],
    "auto": true
  },
  {
    "id": "mach_m249",
    "name": "M249",
    "kind": "mach",
    "capacity": 100,
    "damage": 28,
    "delay": 0.08,
    "price": 5200,
    "mass": 7.5,
    "reserve": 300,
    "events": [
      [
        0.53333336,
        "mach_m249_reload_0.ogg"
      ],
      [
        1.3333334,
        "mach_m249_reload_1.ogg"
      ],
      [
        2.5,
        "mach_m249_reload_2.ogg"
      ],
      [
        2.8333333,
        "mach_m249_reload_3.ogg"
      ],
      [
        3.7,
        "mach_m249_reload_4.ogg"
      ],
      [
        4.4333334,
        "mach_m249_reload_5.ogg"
      ]
    ],
    "size": [
      1.2871431112289429,
      0.21376162767410278,
      0.2920250818133354
    ],
    "auto": true
  },
  {
    "id": "mach_negev",
    "name": "Negev",
    "kind": "mach",
    "capacity": 150,
    "damage": 26,
    "delay": 0.075,
    "price": 1700,
    "mass": 7.6,
    "reserve": 450,
    "events": [
      [
        0.46666667,
        "mach_negev_reload_0.ogg"
      ],
      [
        1.1,
        "mach_negev_reload_1.ogg"
      ],
      [
        2.1666667,
        "mach_negev_reload_2.ogg"
      ],
      [
        2.4333334,
        "mach_negev_reload_3.ogg"
      ],
      [
        2.9333334,
        "mach_negev_reload_4.ogg"
      ],
      [
        3.6333334,
        "mach_negev_reload_5.ogg"
      ]
    ],
    "size": [
      1.1982775926589966,
      0.22321389615535736,
      0.2758771926164627
    ],
    "auto": true
  },
  {
    "id": "knife",
    "name": "Cuchillo",
    "kind": "knife",
    "capacity": 0,
    "damage": 42,
    "delay": 0.55,
    "price": 0,
    "mass": 0.3,
    "reserve": 0,
    "events": [],
    "size": [
      0,
      0,
      0
    ],
    "auto": false
  }
]

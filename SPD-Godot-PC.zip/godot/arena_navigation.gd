extends NavigationRegion3D


func build(source: MeshInstance3D) -> void:
	var nav := NavigationMesh.new()
	nav.cell_size = 0.25
	nav.cell_height = 0.16
	nav.agent_radius = 0.42
	nav.agent_height = 1.65
	nav.agent_max_climb = 0.38
	nav.agent_max_slope = 45.0
	var geometry := NavigationMeshSourceGeometryData3D.new()
	geometry.add_mesh(source.mesh, global_transform.affine_inverse() * source.global_transform)
	NavigationServer3D.bake_from_source_geometry_data(nav, geometry)
	navigation_mesh = nav

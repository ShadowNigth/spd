extends StaticBody3D

const Pieces = preload("res://combat_assets/fragments.gd")
var life := 55


func _ready() -> void:
	collision_layer = 4
	var box := BoxMesh.new()
	box.size = Vector3.ONE * 2.0
	var paint := StandardMaterial3D.new()
	paint.albedo_color = Color("a57949")
	var body_mesh := MeshInstance3D.new()
	body_mesh.mesh = box
	body_mesh.material_override = paint
	add_child(body_mesh)
	var shape_node := CollisionShape3D.new()
	var shape_box := BoxShape3D.new()
	shape_box.size = box.size
	shape_node.shape = shape_box
	add_child(shape_node)


func take_damage(amount: int) -> void:
	if life <= 0:
		return
	life -= amount
	if life > 0:
		return
	var parent := get_parent()
	var sound := AudioStreamPlayer3D.new()
	sound.stream = preload("res://combat_assets/break.ogg")
	parent.add_child(sound)
	sound.global_position = global_position
	sound.finished.connect(sound.queue_free)
	sound.play()
	for i in range(Pieces.FRAGMENTS.size()):
		var piece := RigidBody3D.new()
		piece.collision_layer = 0
		piece.collision_mask = 1
		var mesh: Mesh = Pieces.FRAGMENTS[i]
		var model := MeshInstance3D.new()
		model.mesh = mesh
		piece.add_child(model)
		var shape_node := CollisionShape3D.new()
		shape_node.shape = mesh.create_convex_shape()
		piece.add_child(shape_node)
		parent.add_child(piece)
		var offset: Vector3 = Pieces.OFFSETS[i]
		piece.global_position = global_position + offset
		piece.apply_central_impulse(offset * 3.0 + Vector3.UP * 2.5)
		piece.apply_torque_impulse(Vector3(offset.z, offset.x, offset.y))
		var timer := Timer.new()
		timer.one_shot = true
		piece.add_child(timer)
		timer.timeout.connect(piece.queue_free)
		timer.start(5.0)
	queue_free()

extends Node3D

const Player = preload("res://player.gd")
const Combat = preload("res://combat.gd")
const Scope = preload("res://scope_overlay.gd")
const Minimap = preload("res://minimap.gd")
const LEVELS := {
	"awp_lego_2": preload("res://maps/awp_lego_2.glb"),
	"2000": preload("res://maps/2000.glb"),
}
const TITLES := {"awp_lego_2": "AWP LEGO 2", "2000": "$2000$"}
const SNAPSHOTS := {
	"awp_lego_2": preload("res://ui/awp_lego_2.png"),
	"2000": preload("res://ui/2000.png"),
}

var ui := CanvasLayer.new()
var screen: Control
var world: Node3D
var player: Player
var combat: Combat
var map_id := ""
var status := ""
var shopping := false
var shop_status := ""


func _ready() -> void:
	for binding in [["left", KEY_A], ["right", KEY_D], ["forward", KEY_W],
			["back", KEY_S], ["jump", KEY_SPACE], ["flashlight", KEY_F], ["reset", KEY_F2],
			["reload", KEY_R], ["inspect", KEY_I], ["weapon_1", KEY_1], ["weapon_2", KEY_2],
			["weapon_3", KEY_3], ["sprint", KEY_SHIFT], ["shop", KEY_B],
			["drop", KEY_G], ["interact", KEY_E]]:
		var action: StringName = binding[0]
		InputMap.add_action(action)
		var event := InputEventKey.new()
		event.physical_keycode = binding[1]
		InputMap.action_add_event(action, event)
	InputMap.add_action("fire")
	var click := InputEventMouseButton.new()
	click.button_index = MOUSE_BUTTON_LEFT
	InputMap.action_add_event("fire", click)
	InputMap.add_action("aim")
	var aim := InputEventMouseButton.new()
	aim.button_index = MOUSE_BUTTON_RIGHT
	InputMap.action_add_event("aim", aim)
	add_child(ui)
	show_menu()


func new_screen() -> Control:
	if is_instance_valid(combat) and combat.hud.get_parent() != null:
		combat.hud.get_parent().remove_child(combat.hud)
	if is_instance_valid(screen):
		ui.remove_child(screen)
		screen.queue_free()
	screen = Control.new()
	screen.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	screen.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui.add_child(screen)
	return screen


func label(text: String, size: int, box: Container) -> void:
	var item := Label.new()
	item.text = text
	item.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	item.add_theme_font_size_override("font_size", size)
	box.add_child(item)


func button(text: String, box: Container, callback: Callable) -> void:
	var item := Button.new()
	item.text = text
	item.custom_minimum_size.y = 44
	item.pressed.connect(callback)
	box.add_child(item)


func panel(color: Color) -> VBoxContainer:
	var tint := ColorRect.new()
	tint.color = color
	tint.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	new_screen().add_child(tint)
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	tint.add_child(center)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 16)
	center.add_child(box)
	return box


func show_menu() -> void:
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	if is_instance_valid(world):
		remove_child(world)
		world.queue_free()
	world = null
	player = null
	combat = null
	var box := panel(Color("111923"))
	label("STRIKE PORT DESTRUCTION", 38, box)
	label("PORT GODOT  /  COMBATE LOCAL PARA PC", 18, box)
	var maps := HBoxContainer.new()
	maps.add_theme_constant_override("separation", 20)
	maps.alignment = BoxContainer.ALIGNMENT_CENTER
	box.add_child(maps)
	for id: String in LEVELS:
		var card := VBoxContainer.new()
		maps.add_child(card)
		var image := TextureRect.new()
		image.texture = SNAPSHOTS[id]
		image.custom_minimum_size = Vector2(250, 250)
		image.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		image.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		card.add_child(image)
		button(TITLES[id], card, open_map.bind(id))
	label("WASD · Moverse    LMB · Disparar    R · Recargar    1–3 · Ranura    I · Inspeccionar    Esc · Pausa", 16, box)
	if not status.is_empty():
		label(status, 16, box)


func open_map(id: String) -> void:
	var spawns: Variant = JSON.parse_string(FileAccess.get_file_as_string("res://maps/%s.json" % id))
	if not spawns is Array or spawns.is_empty():
		status = "No se pudieron leer los puntos de aparición de este mapa."
		show_menu()
		return
	if is_instance_valid(world):
		show_menu()
	world = Node3D.new()
	add_child(world)
	var packed: PackedScene = LEVELS[id]
	var level := packed.instantiate()
	world.add_child(level)
	var collision := level.find_child("Physics", true, false) as MeshInstance3D
	if collision == null or collision.mesh == null:
		status = "No se pudo cargar la geometría de colisión de este mapa."
		show_menu()
		return
	collision.create_trimesh_collision()
	collision.hide()
	var environment := WorldEnvironment.new()
	environment.environment = Environment.new()
	environment.environment.background_mode = Environment.BG_COLOR
	environment.environment.background_color = Color("839bb0")
	environment.environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	environment.environment.ambient_light_color = Color("c8d8ea")
	environment.environment.ambient_light_energy = 0.64
	world.add_child(environment)
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-58, -35, 0)
	sun.light_energy = 0.85
	sun.shadow_enabled = true
	world.add_child(sun)
	var spawn: Dictionary = spawns[0]
	var p: Array = spawn["position"]
	var f: Array = spawn["forward"]
	player = Player.new()
	player.origin = Vector3(p[0], p[1] + 0.15, p[2])
	player.spawn_yaw = atan2(-f[0], -f[2])
	world.add_child(player)
	combat = Combat.new()
	combat.player = player
	combat.spawns = spawns
	combat.map_id = id
	world.add_child(combat)
	map_id = id
	status = ""
	resume()


func resume() -> void:
	shopping = false
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	var hud := new_screen()
	var scope := Scope.new()
	scope.combat = combat
	scope.mouse_filter = Control.MOUSE_FILTER_IGNORE
	scope.hide()
	hud.add_child(scope)
	scope.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var radar := Minimap.new()
	radar.map_id = map_id
	radar.player = player
	radar.combat = combat
	radar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud.add_child(radar)
	radar.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT)
	radar.offset_left = -214
	radar.offset_right = -18
	radar.offset_top = 18
	radar.offset_bottom = 214
	var info := Label.new()
	info.position = Vector2(20, 16)
	info.text = TITLES[map_id] + "   /   COMBATE LOCAL PARA PC\nEsc: pausa   F2: reaparecer"
	info.add_theme_color_override("font_shadow_color", Color.BLACK)
	info.add_theme_constant_override("shadow_offset_x", 1)
	info.add_theme_constant_override("shadow_offset_y", 2)
	hud.add_child(info)
	combat.hud.position = Vector2(20, 62)
	combat.hud.add_theme_color_override("font_shadow_color", Color.BLACK)
	combat.hud.add_theme_constant_override("shadow_offset_y", 2)
	hud.add_child(combat.hud)
	var dot := ColorRect.new()
	dot.color = Color.WHITE
	dot.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud.add_child(dot)
	dot.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	dot.offset_left = -2
	dot.offset_right = 2
	dot.offset_top = -2
	dot.offset_bottom = 2


func open_shop() -> void:
	shopping = true
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	var box := panel(Color(0.035, 0.07, 0.10, 0.95))
	label("ARSENAL  /  $%d" % combat.cash, 30, box)
	label("Comprar reemplaza la ranura y deja el arma anterior en el suelo.", 16, box)
	var scroll := ScrollContainer.new()
	scroll.custom_minimum_size = Vector2(650, 350)
	box.add_child(scroll)
	var grid := GridContainer.new()
	grid.columns = 2
	grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(grid)
	for data: Dictionary in Combat.WEAPONS:
		if data["kind"] == "knife" or not combat.allowed(data):
			continue
		var item := Button.new()
		var role := "Pistola" if data["kind"] == "pist" else "Primaria"
		item.text = "%s: %s — $%d" % [role, data["name"], data["price"]]
		item.custom_minimum_size = Vector2(290, 42)
		item.disabled = combat.cash < int(data["price"])
		item.pressed.connect(purchase.bind(data))
		grid.add_child(item)
	if not shop_status.is_empty():
		label(shop_status, 16, box)
	button("Volver a la partida (B o Esc)", box, resume)


func purchase(data: Dictionary) -> void:
	if combat.buy(data):
		shop_status = "Compraste " + str(data["name"])
	else:
		shop_status = "No se pudo completar la compra."
	open_shop()


func _unhandled_input(event: InputEvent) -> void:
	if not is_instance_valid(player):
		return
	if event.is_action_pressed("shop"):
		if shopping:
			resume()
		elif Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
			if combat.can_shop():
				shop_status = ""
				open_shop()
			else:
				combat.notice = "Compra cerca de la aparición CT o en la zona de compra de $2000$." if map_id == "2000" else "AWP LEGO 2: solo AWP, Desert Eagle y cuchillo."
				combat.notice_left = 2.0
		get_viewport().set_input_as_handled()
		return
	if event.is_action_pressed("ui_cancel"):
		if shopping:
			resume()
			get_viewport().set_input_as_handled()
			return
		if Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
			Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
			var box := panel(Color(0.04, 0.07, 0.10, 0.86))
			label("PAUSA  /  " + TITLES[map_id], 32, box)
			button("Continuar", box, resume)
			button("Reiniciar partida", box, open_map.bind(map_id))
			button("Volver a los mapas", box, show_menu)
		else:
			resume()
	elif event.is_action_pressed("reset") and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		player.reset_spawn()

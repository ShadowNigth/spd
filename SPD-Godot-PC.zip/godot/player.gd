extends CharacterBody3D

const SPEED := 6.0
const SPRINT_SPEED := 8.4
const GROUND_ACCEL := 30.0
const BRAKE := 38.0
const AIR_ACCEL := 8.0
const JUMP := 5.0
const GRAVITY := 16.0
const JUMP_GRACE := 0.09
const SENSITIVITY := 0.0022

var camera := Camera3D.new()
var torch := SpotLight3D.new()
var torch_sound := AudioStreamPlayer.new()
var origin := Vector3.ZERO
var spawn_yaw := 0.0
var coyote := 0.0
var jump_buffer := 0.0


func _ready() -> void:
	collision_mask = 7
	floor_snap_length = 0.22
	floor_stop_on_slope = true
	camera.name = "Camera3D"
	var capsule := CapsuleShape3D.new()
	capsule.radius = 0.32
	capsule.height = 1.72
	var hitbox := CollisionShape3D.new()
	hitbox.shape = capsule
	hitbox.position.y = capsule.height / 2.0
	add_child(hitbox)
	camera.position.y = 1.58
	camera.fov = 75.0
	camera.current = true
	add_child(camera)
	torch.spot_range = 23.0
	torch.spot_angle = 33.0
	torch.light_energy = 2.0
	torch.hide()
	camera.add_child(torch)
	torch_sound.stream = preload("res://audio/flashlight1.wav")
	add_child(torch_sound)
	reset_spawn()


func reset_spawn() -> void:
	position = origin
	velocity = Vector3.ZERO
	coyote = 0.0
	jump_buffer = 0.0
	rotation.y = spawn_yaw
	camera.rotation.x = 0.0


func _unhandled_input(event: InputEvent) -> void:
	if Input.mouse_mode != Input.MOUSE_MODE_CAPTURED:
		return
	if event is InputEventMouseMotion:
		var sensitivity := SENSITIVITY * clampf(camera.fov / 75.0, 0.25, 1.0)
		rotate_y(-event.relative.x * sensitivity)
		camera.rotation.x = clampf(camera.rotation.x - event.relative.y * sensitivity, -1.54, 1.54)
	if event.is_action_pressed("flashlight"):
		torch.visible = not torch.visible
		torch_sound.play()


func _physics_process(delta: float) -> void:
	if Input.mouse_mode != Input.MOUSE_MODE_CAPTURED:
		return
	var grounded := is_on_floor()
	coyote = JUMP_GRACE if grounded else maxf(0.0, coyote - delta)
	jump_buffer = JUMP_GRACE if Input.is_action_just_pressed("jump") else maxf(0.0, jump_buffer - delta)
	var direction := Input.get_vector("left", "right", "forward", "back")
	var sprint := Input.is_action_pressed("sprint") and direction.y < -0.2
	var desired := basis * Vector3(direction.x, 0.0, direction.y) * (SPRINT_SPEED if sprint else SPEED)
	var rate := AIR_ACCEL if not grounded else (BRAKE if direction.is_zero_approx() else GROUND_ACCEL)
	var lateral := Vector2(velocity.x, velocity.z).move_toward(Vector2(desired.x, desired.z), rate * delta)
	velocity.x = lateral.x
	velocity.z = lateral.y
	if jump_buffer > 0.0 and coyote > 0.0:
		velocity.y = JUMP
		jump_buffer = 0.0
		coyote = 0.0
	elif not grounded:
		velocity.y = maxf(velocity.y - GRAVITY * delta, -42.0)
	else:
		velocity.y = 0.0
	move_and_slide()
	if position.y < origin.y - 60.0:
		reset_spawn()

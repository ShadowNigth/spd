extends CharacterBody3D

const SPEED := 6.0
const JUMP := 5.0
const SENSITIVITY := 0.0022

var camera := Camera3D.new()
var torch := SpotLight3D.new()
var torch_sound := AudioStreamPlayer.new()
var origin := Vector3.ZERO
var spawn_yaw := 0.0


func _ready() -> void:
	collision_mask = 7
	camera.name = "Camera3D"
	var capsule := CapsuleShape3D.new()
	capsule.radius = 0.32
	capsule.height = 1.72
	var hitbox := CollisionShape3D.new()
	hitbox.shape = capsule
	hitbox.position.y = capsule.height / 2.0
	add_child(hitbox)
	camera.position.y = 1.58
	camera.fov = 75.0
	camera.current = true
	add_child(camera)
	torch.spot_range = 23.0
	torch.spot_angle = 33.0
	torch.light_energy = 2.0
	torch.hide()
	camera.add_child(torch)
	torch_sound.stream = preload("res://audio/flashlight1.wav")
	add_child(torch_sound)
	reset_spawn()


func reset_spawn() -> void:
	position = origin
	velocity = Vector3.ZERO
	rotation.y = spawn_yaw
	camera.rotation.x = 0.0


func _unhandled_input(event: InputEvent) -> void:
	if Input.mouse_mode != Input.MOUSE_MODE_CAPTURED:
		return
	if event is InputEventMouseMotion:
		rotate_y(-event.relative.x * SENSITIVITY)
		camera.rotation.x = clampf(camera.rotation.x - event.relative.y * SENSITIVITY, -1.54, 1.54)
	if event.is_action_pressed("flashlight"):
		torch.visible = not torch.visible
		torch_sound.play()


func _physics_process(delta: float) -> void:
	var direction := Vector2.ZERO
	if Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		direction = Input.get_vector("left", "right", "forward", "back")
		if is_on_floor() and Input.is_action_just_pressed("jump"):
			velocity.y = JUMP
	if not is_on_floor():
		velocity.y -= 14.0 * delta
	var movement := basis * Vector3(direction.x, 0.0, direction.y)
	velocity.x = movement.x * SPEED
	velocity.z = movement.z * SPEED
	move_and_slide()
	if position.y < origin.y - 60.0:
		reset_spawn()

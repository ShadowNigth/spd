extends CharacterBody3D

signal damage_player(amount: int)
signal defeated

const MODELS := [preload("res://combat_assets/leet.glb"), preload("res://combat_assets/idf.glb")]
var target: CharacterBody3D
var variant := 0
var life := 100
var cooldown := 1.0
var hit_flash := 0.0
var visual := Node3D.new()
var animator: AnimationPlayer
var skin_meshes: Array[Node] = []
var action_time := 0.0
var stop_time := 0.0
var rounds := 7
var path := PackedVector3Array()
var waypoint := 0
var repath := 0.0
var memory := 0.0
var last_seen := Vector3.ZERO
var reaction := 0.0
var strafe_sign := 1.0
var strafe_timer := 0.0
var blocked_time := 0.0
var escape_left := 0.0
var escape_axis := Vector3.ZERO
var shot := AudioStreamPlayer3D.new()
var flash := StandardMaterial3D.new()


func _ready() -> void:
	collision_layer = 2
	collision_mask = 7
	floor_snap_length = 0.23
	strafe_sign = -1.0 if variant == 0 else 1.0
	add_to_group("arena_bots")
	var capsule := CapsuleShape3D.new()
	capsule.height = 1.75
	capsule.radius = 0.34
	var shape_node := CollisionShape3D.new()
	shape_node.shape = capsule
	shape_node.position.y = 0.875
	add_child(shape_node)
	add_child(visual)
	var model: Node = MODELS[variant].instantiate()
	visual.add_child(model)
	var animations := model.find_children("*", "AnimationPlayer", true, false)
	if not animations.is_empty():
		animator = animations[0] as AnimationPlayer
	skin_meshes = model.find_children("*", "MeshInstance3D", true, false)
	play_clip(&"idle", true)
	flash.albedo_color = Color("e15c40")
	shot.stream = preload("res://combat_assets/deagle.ogg")
	shot.volume_db = -12.0
	add_child(shot)


func _physics_process(delta: float) -> void:
	if life <= 0 or not is_instance_valid(target):
		return
	if Input.mouse_mode != Input.MOUSE_MODE_CAPTURED:
		if animator != null:
			animator.speed_scale = 0.0
		return
	if animator != null:
		animator.speed_scale = 1.0
	action_time = maxf(0.0, action_time - delta)
	stop_time = maxf(0.0, stop_time - delta)
	var offset := target.global_position - global_position
	var horizontal := flat(offset)
	var distance := horizontal.length()
	var sight := distance <= 32.0 and sees_target()
	if sight:
		reaction += delta
		memory = 5.0
		last_seen = target.global_position
	else:
		reaction = 0.0
		memory = maxf(0.0, memory - delta)
	var desired := steer(delta, sight, horizontal, distance)
	if stop_time > 0.0:
		desired *= 0.32
	var look := horizontal if sight else desired
	if look.length_squared() > 0.02:
		rotation.y = lerp_angle(rotation.y, atan2(-look.x, -look.z), minf(delta * 9.0, 1.0))
	var speed_target := desired * (2.5 if sight else 3.6)
	var speed_now := Vector2(velocity.x, velocity.z).move_toward(Vector2(speed_target.x, speed_target.z), delta * 11.0)
	velocity.x = speed_now.x
	velocity.z = speed_now.y
	velocity.y = velocity.y - 16.0 * delta if not is_on_floor() else 0.0
	move_and_slide()
	var actual := flat(get_real_velocity()).length()
	blocked_time = blocked_time + delta if desired.length() > 0.4 and actual < 0.35 else maxf(0.0, blocked_time - delta * 2.0)
	if blocked_time > 0.45:
		blocked_time = 0.0
		repath = 0.0
		strafe_sign = -strafe_sign
		var forward := desired.normalized()
		escape_axis = (forward.cross(Vector3.UP) * strafe_sign - forward * 0.25).normalized()
		escape_left = 0.55
	hit_flash = maxf(hit_flash - delta, 0.0)
	for surface in skin_meshes:
		(surface as MeshInstance3D).material_override = flash if hit_flash > 0.0 else null
	if action_time <= 0.0:
		var speed := Vector2(get_real_velocity().x, get_real_velocity().z).length()
		if speed > 1.8:
			play_clip(&"run", true)
		elif speed > 0.15:
			play_clip(&"walk", true)
		else:
			play_clip(&"idle", true)
	cooldown -= delta
	if cooldown > 0.0 or action_time > 0.0 or not sight or reaction < 0.24 or distance > 26.0:
		return
	cooldown = randf_range(0.55, 0.95)
	if rounds == 0:
		rounds = 7
		action_time = play_clip(&"reload")
		stop_time = action_time
		return
	rounds -= 1
	action_time = play_clip(&"aim")
	shot.play()
	hit_flash = 0.05
	if randf() < clampf(0.82 - distance * 0.023, 0.22, 0.79):
		damage_player.emit(9)


func flat(v: Vector3) -> Vector3:
	return Vector3(v.x, 0.0, v.z)


func sees_target() -> bool:
	var query := PhysicsRayQueryParameters3D.create(global_position + Vector3.UP * 1.4,
		target.global_position + Vector3.UP * 1.35, 7, [get_rid()])
	var hit := get_world_3d().direct_space_state.intersect_ray(query)
	return not hit.is_empty() and hit.collider == target


func steer(delta: float, sight: bool, offset: Vector3, distance: float) -> Vector3:
	if escape_left > 0.0:
		escape_left -= delta
		return escape_axis
	var motion := Vector3.ZERO
	if sight and distance < 12.0:
		strafe_timer -= delta
		if strafe_timer <= 0.0:
			strafe_timer = randf_range(0.65, 1.5)
			strafe_sign = -strafe_sign
		var forward := offset.normalized()
		var radial := -0.8 if distance < 3.5 else (0.62 if distance > 8.0 else 0.0)
		motion = forward * radial + forward.cross(Vector3.UP) * strafe_sign * 0.68
	else:
		var goal := last_seen if memory > 0.0 else target.global_position
		if sight:
			goal = target.global_position
		motion = path_direction(goal, delta)
	for other in get_tree().get_nodes_in_group("arena_bots"):
		var body := other as CharacterBody3D
		if body == self or body == null or body.collision_layer == 0:
			continue
		var away := flat(global_position - body.global_position)
		var gap := away.length()
		if gap > 0.01 and gap < 1.35:
			motion += away / gap * (1.35 - gap)
	return motion.limit_length()


func path_direction(goal: Vector3, delta: float) -> Vector3:
	repath -= delta
	var navigation := get_world_3d().navigation_map
	if repath <= 0.0 and NavigationServer3D.map_get_iteration_id(navigation) > 0:
		repath = randf_range(0.24, 0.46)
		path = NavigationServer3D.map_get_path(navigation, global_position, goal, true)
		waypoint = 0
	while waypoint < path.size() and flat(path[waypoint] - global_position).length() < 0.46:
		waypoint += 1
	if waypoint < path.size():
		return flat(path[waypoint] - global_position).normalized()
	return flat(goal - global_position).normalized()


func play_clip(clip: StringName, loop: bool = false) -> float:
	if animator == null or not animator.has_animation(clip):
		return 0.0
	var animation := animator.get_animation(clip)
	animation.loop_mode = Animation.LOOP_LINEAR if loop else Animation.LOOP_NONE
	if animator.current_animation != clip:
		animator.play(clip, 0.09)
	return animation.length


func take_damage(amount: int) -> void:
	if life <= 0:
		return
	life -= amount
	hit_flash = 0.12
	if life <= 0:
		collision_layer = 0
		collision_mask = 0
		defeated.emit()
		if animator != null:
			animator.speed_scale = 1.0
		var length := play_clip(&"die" if variant == 0 else &"die_alt")
		var cleanup := create_tween()
		cleanup.tween_interval(length + 2.0)
		cleanup.tween_callback(queue_free)

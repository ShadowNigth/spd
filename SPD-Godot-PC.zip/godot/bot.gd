extends CharacterBody3D

signal damage_player(amount: int)
signal defeated

const MODELS := [preload("res://combat_assets/leet.glb"), preload("res://combat_assets/idf.glb")]
var target: CharacterBody3D
var variant := 0
var life := 100
var cooldown := 1.0
var hit_flash := 0.0
var visual := Node3D.new()
var animator: AnimationPlayer
var skin_meshes: Array[Node] = []
var action_time := 0.0
var stop_time := 0.0
var rounds := 7
var shot := AudioStreamPlayer3D.new()
var flash := StandardMaterial3D.new()


func _ready() -> void:
	collision_layer = 2
	collision_mask = 7
	var capsule := CapsuleShape3D.new()
	capsule.height = 1.75
	capsule.radius = 0.34
	var shape_node := CollisionShape3D.new()
	shape_node.shape = capsule
	shape_node.position.y = 0.875
	add_child(shape_node)
	add_child(visual)
	var model: Node = MODELS[variant].instantiate()
	visual.add_child(model)
	var animations := model.find_children("*", "AnimationPlayer", true, false)
	if not animations.is_empty():
		animator = animations[0] as AnimationPlayer
	skin_meshes = model.find_children("*", "MeshInstance3D", true, false)
	play_clip(&"idle", true)
	flash.albedo_color = Color("e15c40")
	shot.stream = preload("res://combat_assets/deagle.ogg")
	shot.volume_db = -12.0
	add_child(shot)


func _physics_process(delta: float) -> void:
	if life <= 0 or not is_instance_valid(target):
		return
	if Input.mouse_mode != Input.MOUSE_MODE_CAPTURED:
		if animator != null:
			animator.speed_scale = 0.0
		return
	if animator != null:
		animator.speed_scale = 1.0
	action_time = maxf(0.0, action_time - delta)
	stop_time = maxf(0.0, stop_time - delta)
	var offset := target.global_position - global_position
	var horizontal := Vector3(offset.x, 0.0, offset.z)
	var distance := horizontal.length()
	if distance > 0.1:
		rotation.y = atan2(-horizontal.x, -horizontal.z)
	var motion := horizontal.normalized() * (2.4 if distance > 7.0 and stop_time <= 0.0 else 0.0)
	velocity.x = motion.x
	velocity.z = motion.z
	velocity.y = velocity.y - 14.0 * delta if not is_on_floor() else 0.0
	move_and_slide()
	hit_flash = maxf(hit_flash - delta, 0.0)
	for surface in skin_meshes:
		(surface as MeshInstance3D).material_override = flash if hit_flash > 0.0 else null
	if action_time <= 0.0:
		var speed := Vector2(get_real_velocity().x, get_real_velocity().z).length()
		if speed > 1.8:
			play_clip(&"run", true)
		elif speed > 0.15:
			play_clip(&"walk", true)
		else:
			play_clip(&"idle", true)
	cooldown -= delta
	if cooldown > 0.0 or action_time > 0.0 or distance > 26.0:
		return
	cooldown = 0.75 + variant * 0.2
	var query := PhysicsRayQueryParameters3D.create(global_position + Vector3.UP * 1.4,
		target.global_position + Vector3.UP * 1.35, 7, [get_rid()])
	var hit := get_world_3d().direct_space_state.intersect_ray(query)
	if not hit.is_empty() and hit.collider == target:
		if rounds == 0:
			rounds = 7
			action_time = play_clip(&"reload")
			stop_time = action_time
			return
		rounds -= 1
		action_time = play_clip(&"aim")
		shot.play()
		hit_flash = 0.05
		damage_player.emit(8)


func play_clip(clip: StringName, loop: bool = false) -> float:
	if animator == null or not animator.has_animation(clip):
		return 0.0
	var animation := animator.get_animation(clip)
	animation.loop_mode = Animation.LOOP_LINEAR if loop else Animation.LOOP_NONE
	if animator.current_animation != clip:
		animator.play(clip, 0.09)
	return animation.length


func take_damage(amount: int) -> void:
	if life <= 0:
		return
	life -= amount
	hit_flash = 0.12
	if life <= 0:
		collision_layer = 0
		collision_mask = 0
		defeated.emit()
		if animator != null:
			animator.speed_scale = 1.0
		var length := play_clip(&"die" if variant == 0 else &"die_alt")
		var cleanup := create_tween()
		cleanup.tween_interval(length + 2.0)
		cleanup.tween_callback(queue_free)

extends CharacterBody3D

signal damage_player(amount: int)
signal defeated

const MODELS := [preload("res://combat_assets/leet.glb"), preload("res://combat_assets/idf.glb")]
var target: CharacterBody3D
var variant := 0
var life := 100
var time := 0.0
var cooldown := 1.0
var hit_flash := 0.0
var visual := Node3D.new()
var rig: Skeleton3D
var skin_meshes: Array[Node] = []
var motion_phase := 0.0
var shoot_kick := 0.0
var shot := AudioStreamPlayer3D.new()
var flash := StandardMaterial3D.new()


func _ready() -> void:
	collision_layer = 2
	collision_mask = 7
	var capsule := CapsuleShape3D.new()
	capsule.height = 1.75
	capsule.radius = 0.34
	var shape_node := CollisionShape3D.new()
	shape_node.shape = capsule
	shape_node.position.y = 0.875
	add_child(shape_node)
	add_child(visual)
	var model: Node = MODELS[variant].instantiate()
	visual.add_child(model)
	var rigs := model.find_children("*", "Skeleton3D", true, false)
	if not rigs.is_empty():
		rig = rigs[0] as Skeleton3D
	skin_meshes = model.find_children("*", "MeshInstance3D", true, false)
	pose(false)
	flash.albedo_color = Color("e15c40")
	shot.stream = preload("res://combat_assets/deagle.ogg")
	shot.volume_db = -12.0
	add_child(shot)


func _physics_process(delta: float) -> void:
	if life <= 0 or not is_instance_valid(target) or Input.mouse_mode != Input.MOUSE_MODE_CAPTURED:
		return
	var offset := target.global_position - global_position
	var horizontal := Vector3(offset.x, 0.0, offset.z)
	var distance := horizontal.length()
	if distance > 0.1:
		rotation.y = atan2(-horizontal.x, -horizontal.z)
	var motion := horizontal.normalized() * (2.4 if distance > 7.0 else 0.0)
	velocity.x = motion.x
	velocity.z = motion.z
	velocity.y = velocity.y - 14.0 * delta if not is_on_floor() else 0.0
	move_and_slide()
	time += delta
	hit_flash = maxf(hit_flash - delta, 0.0)
	for surface in skin_meshes:
		(surface as MeshInstance3D).material_override = flash if hit_flash > 0.0 else null
	shoot_kick = move_toward(shoot_kick, 0.0, delta * 5.0)
	motion_phase += delta * 10.0
	pose(motion.length() > 0.1)
	visual.position.y = absf(sin(time * 11.0)) * (0.05 if motion.length() > 0.1 else 0.012)
	visual.rotation.z = sin(time * 11.0) * (0.04 if motion.length() > 0.1 else 0.014)
	cooldown -= delta
	if cooldown > 0.0 or distance > 26.0:
		return
	cooldown = 0.75 + variant * 0.2
	var query := PhysicsRayQueryParameters3D.create(global_position + Vector3.UP * 1.4,
		target.global_position + Vector3.UP * 1.35, 7, [get_rid()])
	var hit := get_world_3d().direct_space_state.intersect_ray(query)
	if not hit.is_empty() and hit.collider == target:
		shot.play()
		shoot_kick = 1.0
		hit_flash = 0.05
		damage_player.emit(8)


func pose(moving: bool) -> void:
	if rig == null:
		return
	var swing := sin(motion_phase) * 0.42 if moving else 0.0
	for side in ["L", "R"]:
		var sign_side := 1.0 if side == "L" else -1.0
		var stem := "Bip01 " + str(side) + " "
		var arm := rig.find_bone(stem + "UpperArm")
		if arm >= 0:
			var x := rig.get_bone_global_rest(arm).origin.x
			bend(stem + "UpperArm", Vector3.BACK, -signf(x) * 0.94)
		bend(stem + "Forearm", Vector3.RIGHT, -0.42 + shoot_kick * 0.28)
		bend(stem + "Thigh", Vector3.RIGHT, sign_side * swing)
		bend(stem + "Calf", Vector3.RIGHT, maxf(-sign_side * swing, 0.0) * 0.8)
	bend("Bip01 Spine1", Vector3.RIGHT, sin(time * 2.8) * 0.035 - shoot_kick * 0.08)


func bend(bone_name: String, model_axis: Vector3, angle: float) -> void:
	var i := rig.find_bone(bone_name)
	if i < 0:
		return
	var rest := rig.get_bone_rest(i).basis.orthonormalized().get_rotation_quaternion()
	var in_bone := (rig.get_bone_global_rest(i).basis.inverse() * model_axis).normalized()
	rig.set_bone_pose_rotation(i, rest * Quaternion(in_bone, angle))


func take_damage(amount: int) -> void:
	if life <= 0:
		return
	life -= amount
	hit_flash = 0.12
	if life <= 0:
		collision_layer = 0
		collision_mask = 0
		defeated.emit()
		var fall := create_tween()
		fall.tween_property(visual, "rotation:z", PI * 0.5, 0.25)
		fall.parallel().tween_property(visual, "position:y", 0.2, 0.25)
		fall.tween_interval(2.5)
		fall.tween_callback(queue_free)

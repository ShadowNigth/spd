# Strike Port Destruction — port a Godot

Este repositorio conserva la [extracción original de Unity](decompiled/README.md). `godot/` contiene un modo de combate local para PC en los dos mapas originales. No usa red ni controles táctiles.

## Abrir el proyecto

Importá `godot/project.godot` en **Godot 4** (edición estándar, no requiere .NET), esperá a que terminen las importaciones y presioná **F5**. Elegí **AWP LEGO 2** o **$2000$**.

| Control | Acción |
| --- | --- |
| WASD + mouse | Moverse y apuntar |
| Clic izquierdo | Disparar; mantener para fuego automático con el AK-47 |
| 1 / 2 | AK-47 / Desert Eagle |
| R | Recargar |
| Espacio / F | Saltar / linterna |
| F2 | Volver al punto de aparición sin reiniciar la partida |
| Esc | Pausar, reiniciar o volver a los mapas |

El HUD muestra arma, cargador, reserva, salud y rivales restantes. Los bots aparecen en marcadores T, intentan acercarse y solo disparan con línea de visión; no tienen navegación por malla. Al derrotarlos ganás la partida. Las cajas cerca del punto inicial se rompen con disparos y expulsan las 11 piezas del prefab original `dcube`. No se destruye la geometría fija del mapa.

## Qué se reutiliza y qué se reimplementó

- **Mapas:** mallas visibles, texturas de color, colisiones y 68 marcadores CT/T originales. Godot usa iluminación provisional; los eventos y zonas de Unity no se ejecutan.
- **Armas:** mallas, texturas y sonidos del AK-47 y la Desert Eagle. El arma en pantalla usa la malla del objeto de suelo; el retroceso y la recarga se animan en Godot, no con los clips de manos de Unity.
- **Personajes:** mallas y materiales de LEET A e IDF, con las jerarquías, matrices de bind y pesos de los huesos originales. Marcha, respiración, reacción al disparo y caída se recrean en Godot de forma procedural. No se trasladaron los clips originales uno a uno.
- **Combate y destrucción:** daño, munición, recargas, bots y fragmentación se reimplementaron sin Photon ni el runtime de Unity. Faltan el resto del arsenal, variantes, animaciones originales y otros objetos destructibles.

## Regenerar y verificar

Desde la raíz, con Python 3.9 o posterior y sin dependencias externas:

```sh
python3 tools/port_maps.py
python3 tools/port_combat_assets.py
python3 -m unittest discover -s tools -v
```

Los conversores trabajan con el YAML y los binarios de malla de las exportaciones existentes. `port_maps.py` resuelve GUID, submallas de lotes estáticos y colisiones. `port_combat_assets.py` extrae los modelos y sonidos seleccionados y decodifica las mallas comprimidas de `dcube`; `port_skin.py` convierte los personajes a GLB con skin. No son importadores generales de Unity.

Para probar en una máquina con Godot instalado:

```sh
godot --headless --path godot --editor --import
godot --path godot
```

Para empaquetar una versión de escritorio, incluí `maps/*.json` en el filtro de archivos no reconocidos como recursos del preset. La prueba de datos verifica la estructura de los mapas, la colisión debajo del punto inicial, los pesos del esqueleto y las mallas de armas y fragmentos. No sustituye una prueba en el motor.

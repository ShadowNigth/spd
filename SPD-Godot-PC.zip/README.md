# Strike Port Destruction — port a Godot

Este repositorio conserva la [extracción original de Unity](decompiled/README.md). `godot/` contiene un modo de combate local para PC en los dos mapas originales. No usa red ni controles táctiles.

## Abrir el proyecto

Importá `godot/project.godot` en **Godot 4** (edición estándar, no requiere .NET), esperá a que terminen las importaciones y presioná **F5**. Elegí **AWP LEGO 2** o **$2000$**.

| Control | Acción |
| --- | --- |
| WASD + mouse | Moverse y apuntar |
| Clic izquierdo | Disparar; mantener para fuego automático con el AK-47 |
| 1 / 2 / 3 | Primaria / secundaria / cuchillo |
| E / G | Recoger el arma cercana / soltar la equipada |
| B | Menú de compra cerca de las apariciones CT o en la zona de compra original de $2000$ |
| Clic derecho | Activar o desactivar la mira de un rifle de francotirador |
| Shift + avanzar | Correr |
| R / I | Recargar / inspeccionar el arma |
| Espacio / F | Saltar / linterna |
| F2 | Volver al punto de aparición sin reiniciar la partida |
| Esc | Pausar, reiniciar o volver a los mapas |

El HUD muestra salud, dinero, munición, las tres ranuras y un minimapa con orientación y armas del suelo. En AWP LEGO 2 el equipo inicial y permitido es AWP, Desert Eagle y cuchillo. En $2000$ se puede comprar y recoger armas en 36 puntos originales de Unity. Comprar o recoger una primaria/secundaria reemplaza solo la ranura correspondiente y deja en el suelo el arma anterior con su munición. Los bots aparecen en marcadores T, intentan acercarse y solo disparan con línea de visión; no tienen navegación por malla. Al derrotarlos ganás la partida. Se retiraron las cajas de práctica. La geometría fija de los mapas permanece intacta.

## Qué se reutiliza y qué se reimplementó

- **Mapas:** mallas visibles, texturas de color, colisiones y 68 marcadores CT/T originales. Godot usa iluminación provisional; los eventos y zonas de Unity no se ejecutan.
- **Armas:** modelos originales de primera persona de las 32 armas de fuego del repositorio y el cuchillo, con los antebrazos y guantes CT. Se migraron los clips de sacar el arma, reposo, disparo, recarga e inspección, y los sonidos sincronizados de recarga.
- **Personajes:** mallas y materiales de LEET A e IDF, con las jerarquías, matrices de bind y pesos de los huesos originales. Se adaptaron clips originales Bip01 de reposo, marcha, carrera, puntería, recarga y caída a ambos esqueletos.
- **Combate:** daño, munición, recargas y lógica de bots funcionan sin Photon ni el runtime de Unity. Los disparos tienen destello, trazadoras y chispas en las superficies. El movimiento usa aceleración, frenado, control en el aire, ajuste al suelo y una breve tolerancia para saltar al borde de una plataforma.

## Regenerar y verificar

Desde la raíz, con Python 3.9 o posterior y Pillow para la conversión de texturas y minimapas:

```sh
python3 tools/port_maps.py
python3 tools/port_combat_assets.py
python3 -m pip install Pillow
python3 tools/port_viewmodels.py
python3 tools/port_arena_layout.py
python3 -m unittest discover -s tools -v
```

Los conversores trabajan con el YAML y los binarios de malla de las exportaciones existentes. `port_maps.py` resuelve GUID, submallas de lotes estáticos y colisiones. `port_combat_assets.py` extrae los modelos y sonidos seleccionados y decodifica las mallas comprimidas de `dcube`; `port_skin.py` convierte los personajes a GLB con skin, `port_bot_clips.py` adapta clips Bip01 y `port_viewmodels.py` combina armas, brazos y clips de primera persona. `port_arena_layout.py` extrae las posiciones originales de armas de $2000$ y proyecta las colisiones al minimapa. No son importadores generales de Unity. Las granadas y el C4 no están en el inventario de este modo local.

Para probar en una máquina con Godot instalado:

```sh
godot --headless --path godot --editor --import
godot --path godot
```

Para empaquetar una versión de escritorio, incluí `maps/*.json` en el filtro de archivos no reconocidos como recursos del preset. La prueba de datos verifica la estructura de los mapas, la colisión debajo del punto inicial, los pesos del esqueleto y las mallas de armas y fragmentos. No sustituye una prueba en el motor.

## Audio de `archi` y movimiento en primera persona

El juego reemplaza eventos de disparo, equipamiento y recarga cuando hay un WAV equivalente en `ShadowNigth/archi`. Los demás conservan los sonidos de SPD. La Desert Eagle usa también las nueve señales de inspección, ajustadas a la duración del clip local. `godot/combat_assets/archi/SOURCES.md` registra el commit y los blobs de origen. `python3 tools/import_archi_audio.py` vuelve a importar los archivos seleccionados con `gh` autenticado.

Las secuencias `.mdl`/`.ani` de Source no se importan en esta versión. Se conservan los clips esqueléticos existentes y Godot añade movimiento al caminar, correr, aterrizar, mover el mouse, inspeccionar y disparar, con la capa desactivada al usar la mira.
